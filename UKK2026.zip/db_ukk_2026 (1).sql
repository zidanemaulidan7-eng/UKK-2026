-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 11 Nov 2026 pada 06.28
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ukk_2026`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_transaksi`
--

CREATE TABLE `detail_transaksi` (
  `id_detail` int(11) NOT NULL,
  `id_transaksi` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` decimal(12,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_pelanggaran`
--

CREATE TABLE `kategori_pelanggaran` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama_pelanggan` varchar(100) NOT NULL,
  `no_hp` varchar(15) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `no_hp`, `alamat`, `created_at`) VALUES
(1, 'Pelanggan Umum', '0800000000', '-', '2026-09-18 10:08:18'),
(2, 'Budi', '08123456789', 'Tasikmalaya', '2026-09-18 10:08:18'),
(3, 'Siti', '08234567890', 'Tasikmalaya', '2026-09-18 10:08:18');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `kode_produk` varchar(20) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `harga` decimal(12,2) NOT NULL DEFAULT 0.00,
  `stok` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `kode_produk`, `nama_produk`, `harga`, `stok`, `created_at`) VALUES
(1, 'P001', 'Produk A', 10000.00, 20, '2026-09-18 10:08:18'),
(2, 'P002', 'Produk B', 15000.00, 15, '2026-09-18 10:08:18'),
(3, 'P003', 'Produk C', 20000.00, 10, '2026-09-18 10:08:18');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `tanggal_transaksi` datetime NOT NULL DEFAULT current_timestamp(),
  `id_user` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_guru`
--

CREATE TABLE `t_guru` (
  `id` int(11) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `nama` varchar(150) DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `status_aktif` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_guru`
--

INSERT INTO `t_guru` (`id`, `nip`, `nama`, `email`, `status_aktif`, `user_id`, `created_at`, `updated_at`) VALUES
(1, '198001010001', 'Ahmad Hidayat', 'ahmad.hidayat@gmail.com', 1, 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(2, '198102020002', 'Budi Santoso', 'budi.santoso@gmail.com', 1, 2, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(3, '198203030003', 'Citra Lestari', 'citra.lestari@gmail.com', 1, 3, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(4, '198304040004', 'Dedi Kurniawan', 'dedi.kurniawan@gmail.com', 1, 4, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(5, '198405050005', 'Eka Wulandari', 'eka.wulandari@gmail.com', 1, 5, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(6, '198506060006', 'Fajar Nugraha', 'fajar.nugraha@gmail.com', 1, 6, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(7, '198607070007', 'Gina Permata', 'gina.permata@gmail.com', 1, 7, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(8, '198708080008', 'Hendra Wijaya', 'hendra.wijaya@gmail.com', 1, 8, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(9, '198809090009', 'Indah Sari', 'indah.sari@gmail.com', 1, 9, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(10, '198910100010', 'Joko Susanto', 'joko.susanto@gmail.com', 1, 10, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(11, '198011110011', 'Kartika Dewi', 'kartika.dewi@gmail.com', 1, 11, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(12, '198112120012', 'Lukman Hakim', 'lukman.hakim@gmail.com', 1, 12, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(13, '198213130013', 'Maya Sari', 'maya.sari@gmail.com', 1, 13, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(14, '198314140014', 'Nanda Saputra', 'nanda.saputra@gmail.com', 1, 14, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(15, '198415150015', 'Olivia Putri', 'olivia.putri@gmail.com', 1, 15, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(16, '198516160016', 'Pandu Setiawan', 'pandu.setiawan@gmail.com', 1, 16, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(17, '198617170017', 'Qori Ananda', 'qori.ananda@gmail.com', 1, 17, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(18, '198718180018', 'Rudi Hartono', 'rudi.hartono@gmail.com', 1, 18, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(19, '198819190019', 'Siti Rahma', 'siti.rahma@gmail.com', 1, 19, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(20, '198920200020', 'Taufik Hidayat', 'taufik.hidayat@gmail.com', 1, 20, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(21, '198021210021', 'Umi Kalsum', 'umi.kalsum@gmail.com', 1, 21, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(22, '198122220022', 'Vina Maharani', 'vina.maharani@gmail.com', 1, 22, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(23, '198223230023', 'Wahyu Ramadhan', 'wahyu.ramadhan@gmail.com', 1, 23, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(24, '198324240024', 'Yuni Astuti', 'yuni.astuti@gmail.com', 1, 24, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(25, '198425250025', 'Zainal Abidin', 'zainal.abidin@gmail.com', 1, 25, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(26, '198526260026', 'Agus Setiawan', 'agus.setiawan@gmail.com', 1, 26, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(27, '198627270027', 'Bella Anggraini', 'bella.anggraini@gmail.com', 1, 27, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(28, '198728280028', 'Cahyo Pratama', 'cahyo.pratama@gmail.com', 1, 28, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(29, '198829290029', 'Dian Puspita', 'dian.puspita@gmail.com', 1, 29, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(30, '198930300030', 'Eko Prasetyo', 'eko.prasetyo@gmail.com', 1, 30, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(31, '198031310031', 'Fitria Ningsih', 'fitria.ningsih@gmail.com', 1, 31, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(32, '198132320032', 'Galih Firmansyah', 'galih.firmansyah@gmail.com', 1, 32, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(33, '198233330033', 'Hani Marlina', 'hani.marlina@gmail.com', 1, 33, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(34, '198334340034', 'Irwan Maulana', 'irwan.maulana@gmail.com', 1, 34, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(35, '198435350035', 'Jihan Safitri', 'jihan.safitri@gmail.com', 1, 35, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(36, '198536360036', 'Kurniawan Dwi', 'kurniawan.dwi@gmail.com', 1, 36, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(37, '198637370037', 'Lilis Karlina', 'lilis.karlina@gmail.com', 1, 37, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(38, '198738380038', 'Maman Suherman', 'maman.suherman@gmail.com', 1, 38, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(39, '198839390039', 'Nia Ramadhani', 'nia.ramadhani@gmail.com', 1, 39, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(40, '198940400040', 'Oki Setiawan', 'oki.setiawan@gmail.com', 1, 40, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(41, '198041410041', 'Putri Amelia', 'putri.amelia@gmail.com', 1, 41, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(42, '198142420042', 'Rian Kurnia', 'rian.kurnia@gmail.com', 1, 42, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(43, '198243430043', 'Salsa Nabila', 'salsa.nabila@gmail.com', 1, 43, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(44, '198344440044', 'Teguh Prakoso', 'teguh.prakoso@gmail.com', 1, 44, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(45, '198445450045', 'Utami Sari', 'utami.sari@gmail.com', 1, 45, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(46, '198546460046', 'Vicky Ramadhan', 'vicky.ramadhan@gmail.com', 1, 46, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(47, '198647470047', 'Wulan Pertiwi', 'wulan.pertiwi@gmail.com', 1, 47, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(48, '198748480048', 'Yusuf Maulana', 'yusuf.maulana@gmail.com', 1, 48, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(49, '198849490049', 'Zahra Aulia', 'zahra.aulia@gmail.com', 1, 49, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(50, '198950500050', 'Andi Firmansyah', 'andi.firmansyah@gmail.com', 1, 50, '2026-07-01 01:00:00', '2026-07-01 01:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_kategori_pelanggaran`
--

CREATE TABLE `t_kategori_pelanggaran` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `poin` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_kategori_pelanggaran`
--

INSERT INTO `t_kategori_pelanggaran` (`id_kategori`, `nama_kategori`, `deskripsi`, `poin`) VALUES
(1, 'Kedisiplinan 1', 'Deskripsi kategori untuk pelanggaran kedisiplinan siswa.', 0),
(2, 'Kerapian 1', 'Deskripsi kategori untuk pelanggaran kerapian berpakaian dan atribut.', 0),
(3, 'Kehadiran 1', 'Deskripsi kategori untuk pelanggaran kehadiran dan ketepatan waktu.', 0),
(4, 'Ketertiban 1', 'Deskripsi kategori untuk pelanggaran ketertiban lingkungan sekolah.', 0),
(5, 'Perlengkapan 1', 'Deskripsi kategori untuk pelanggaran kelengkapan belajar siswa.', 0),
(6, 'Sikap 1', 'Deskripsi kategori untuk pelanggaran sikap dan etika siswa.', 0),
(7, 'Kebersihan 1', 'Deskripsi kategori untuk pelanggaran kebersihan kelas dan sekolah.', 0),
(8, 'Keamanan 1', 'Deskripsi kategori untuk pelanggaran aturan keamanan sekolah.', 0),
(9, 'Akademik 1', 'Deskripsi kategori untuk pelanggaran kegiatan belajar dan tugas.', 0),
(10, 'kerapihan 2', 'deksripsi kategori untuk pelanggaran baju sekolah', 0),
(11, 'Terlambat Datang ke Sekolah', '', 5),
(12, 'Tidak Memakai Seragam Sesuai Aturan', '', 5),
(13, 'Tidak Memakai Atribut Sekolah', '', 3),
(14, 'Tidak Mengerjakan Tugas', '', 3),
(15, 'Makan di Kelas', '', 1),
(16, 'Tidur di Kelas', '', 10),
(17, 'Membolos Sekolah', '', 10),
(18, 'Tidak Mengikuti Upacara', '', 5),
(19, 'Berkelahi dengan Teman', '', 15),
(20, 'Merokok di Lingkungan Sekolah', '', 20),
(21, 'Berkata Tidak Sopan', '', 5),
(22, 'Merusak Fasilitas Sekolah', '', 15),
(23, 'Keluar Kelas Tanpa Izin', '', 5),
(24, 'Tidak Mengikuti Kegiatan Sekolah', '', 5),
(25, 'Membawa Barang Terlarang', '', 20),
(26, 'Terlambat Datang ke Sekolah', NULL, 5),
(27, 'Tidak Memakai Seragam Sesuai Aturan', NULL, 5),
(28, 'Tidak Memakai Atribut Sekolah', NULL, 3),
(29, 'Tidak Mengerjakan Tugas', NULL, 3),
(30, 'Makan di Kelas', NULL, 1),
(31, 'Tidur di Kelas', NULL, 10),
(32, 'Membolos Sekolah', NULL, 10),
(33, 'Tidak Mengikuti Upacara', NULL, 5),
(34, 'Berkelahi dengan Teman', NULL, 15),
(35, 'Merokok di Lingkungan Sekolah', NULL, 20),
(36, 'Berkata Tidak Sopan', NULL, 5),
(37, 'Merusak Fasilitas Sekolah', NULL, 15),
(38, 'Keluar Kelas Tanpa Izin', NULL, 5),
(39, 'Tidak Mengikuti Kegiatan Sekolah', NULL, 5),
(40, 'Membawa Barang Terlarang', NULL, 20);

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_kelas`
--

CREATE TABLE `t_kelas` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `tingkat` varchar(20) NOT NULL,
  `jurusan` varchar(100) NOT NULL,
  `status_aktif` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_kelas`
--

INSERT INTO `t_kelas` (`id`, `nama`, `tingkat`, `jurusan`, `status_aktif`, `created_at`, `updated_at`) VALUES
(1, 'BD', 'XI', 'BD', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(2, 'TSM 1', 'XI', 'TSM', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(3, 'TSM 2', 'XI', 'TSM', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(4, 'TSM 3', 'XI', 'TSM', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(5, 'RPL 1', 'XI', 'RPL', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(6, 'RPL 2', 'XI', 'RPL', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(7, 'TKJ 1', 'XI', 'TKJ', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(8, 'TKJ 2', 'XI', 'TKJ', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(9, 'TKJ 3', 'XI', 'TKJ', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(10, 'TKJ 4', 'XI', 'TKJ', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(11, 'TKR 1', 'XI', 'TKR', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(12, 'TKR 2', 'XI', 'TKR', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(13, 'TKR 3', 'XI', 'TKR', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(14, 'TKR 4', 'XI', 'TKR', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(15, 'BD', 'XI', 'BD', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(16, 'TSM 1', 'XI', 'TSM', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(17, 'TSM 2', 'XI', 'TSM', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(18, 'TSM 3', 'XI', 'TSM', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(19, 'RPL 1', 'XI', 'RPL', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(20, 'RPL 2', 'XI', 'RPL', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(21, 'TKJ 1', 'XI', 'TKJ', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(22, 'TKJ 2', 'XI', 'TKJ', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(23, 'TKJ 3', 'XI', 'TKJ', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(24, 'TKJ 4', 'XI', 'TKJ', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(25, 'TKR 1', 'XI', 'TKR', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(26, 'TKR 2', 'XI', 'TKR', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(27, 'TKR 3', 'XI', 'TKR', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(28, 'TKR 4', 'XI', 'TKR', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(29, 'BD', 'XI', 'BD', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(30, 'TSM 1', 'XI', 'TSM', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(31, 'TSM 2', 'XI', 'TSM', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(32, 'TSM 3', 'XI', 'TSM', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(33, 'RPL 1', 'XI', 'RPL', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(34, 'RPL 2', 'XI', 'RPL', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(35, 'TKJ 1', 'XI', 'TKJ', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(36, 'TKJ 2', 'XI', 'TKJ', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(37, 'TKJ 3', 'XI', 'TKJ', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(38, 'TKJ 4', 'XI', 'TKJ', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(39, 'TKR 1', 'XI', 'TKR', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(40, 'TKR 2', 'XI', 'TKR', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(41, 'TKR 3', 'XI', 'TKR', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(42, 'TKR 4', 'XI', 'TKR', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(43, 'BD', 'XI', 'BD', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(44, 'TSM 1', 'XI', 'TSM', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(45, 'TSM 2', 'XI', 'TSM', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(46, 'TSM 3', 'XI', 'TSM', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(47, 'RPL 1', 'XI', 'RPL', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(48, 'RPL 2', 'XI', 'RPL', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(49, 'TKJ 1', 'XI', 'TKJ', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(50, 'TKJ 2', 'XI', 'TKJ', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(51, 'TKJ 3', 'XI', 'TKJ', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(52, 'TKJ 4', 'XI', 'TKJ', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(53, 'TKR 1', 'XI', 'TKR', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(54, 'TKR 2', 'XI', 'TKR', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(55, 'TKR 3', 'XI', 'TKR', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(56, 'TKR 4', 'XI', 'TKR', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(57, 'BD', 'XI', 'BD', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(58, 'TSM 1', 'XI', 'TSM', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(59, 'TSM 2', 'XI', 'TSM', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(60, 'TSM 3', 'XI', 'TSM', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(61, 'RPL 1', 'XI', 'RPL', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(62, 'RPL 2', 'XI', 'RPL', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(63, 'TKJ 1', 'XI', 'TKJ', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(64, 'TKJ 2', 'XI', 'TKJ', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(65, 'TKJ 3', 'XI', 'TKJ', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(66, 'TKJ 4', 'XI', 'TKJ', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(67, 'TKR 1', 'XI', 'TKR', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(68, 'TKR 2', 'XI', 'TKR', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(69, 'TKR 3', 'XI', 'TKR', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(70, 'TKR 4', 'XI', 'TKR', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(71, 'BD', 'XI', 'BD', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(72, 'TSM 1', 'XI', 'TSM', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(73, 'TSM 2', 'XI', 'TSM', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(74, 'TSM 3', 'XI', 'TSM', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(75, 'RPL 1', 'XI', 'RPL', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(76, 'RPL 2', 'XI', 'RPL', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(77, 'TKJ 1', 'XI', 'TKJ', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(78, 'TKJ 2', 'XI', 'TKJ', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(79, 'TKJ 3', 'XI', 'TKJ', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(80, 'TKJ 4', 'XI', 'TKJ', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(81, 'TKR 1', 'XI', 'TKR', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(82, 'TKR 2', 'XI', 'TKR', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(83, 'TKR 3', 'XI', 'TKR', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(84, 'TKR 4', 'XI', 'TKR', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(85, 'BD', 'XI', 'BD', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(86, 'TSM 1', 'XI', 'TSM', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(87, 'TSM 2', 'XI', 'TSM', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(88, 'TSM 3', 'XI', 'TSM', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(89, 'RPL 1', 'XI', 'RPL', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(90, 'RPL 2', 'XI', 'RPL', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(91, 'TKJ 1', 'XI', 'TKJ', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(92, 'TKJ 2', 'XI', 'TKJ', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(93, 'TKJ 3', 'XI', 'TKJ', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(94, 'TKJ 4', 'XI', 'TKJ', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(95, 'TKR 1', 'XI', 'TKR', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(96, 'TKR 2', 'XI', 'TKR', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(97, 'TKR 3', 'XI', 'TKR', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(98, 'TKR 4', 'XI', 'TKR', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(99, 'BD', 'XI', 'BD', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(100, 'TSM 1', 'XI', 'TSM', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_kelas_siswa`
--

CREATE TABLE `t_kelas_siswa` (
  `id` int(11) NOT NULL,
  `siswa_id` int(11) DEFAULT NULL,
  `tahun_ajaran_id` int(11) DEFAULT NULL,
  `kelas_id` int(11) DEFAULT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date NOT NULL,
  `status_aktif` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_kelas_siswa`
--

INSERT INTO `t_kelas_siswa` (`id`, `siswa_id`, `tahun_ajaran_id`, `kelas_id`, `tanggal_mulai`, `tanggal_selesai`, `status_aktif`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, '2026-07-01', '0000-00-00', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(2, 2, 1, 2, '2026-07-01', '0000-00-00', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(3, 3, 1, 3, '2026-07-01', '0000-00-00', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(4, 4, 1, 4, '2026-07-01', '0000-00-00', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(5, 5, 1, 5, '2026-07-01', '0000-00-00', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(6, 6, 1, 6, '2026-07-01', '0000-00-00', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(7, 7, 1, 7, '2026-07-01', '0000-00-00', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(8, 8, 1, 8, '2026-07-01', '0000-00-00', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(9, 9, 1, 9, '2026-07-01', '0000-00-00', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(10, 10, 1, 10, '2026-07-01', '0000-00-00', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(11, 11, 1, 11, '2026-07-01', '0000-00-00', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(12, 12, 1, 12, '2026-07-01', '0000-00-00', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(13, 13, 1, 13, '2026-07-01', '0000-00-00', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(14, 14, 1, 14, '2026-07-01', '0000-00-00', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(15, 15, 1, 1, '2026-07-01', '0000-00-00', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(16, 16, 1, 2, '2026-07-01', '0000-00-00', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(17, 17, 1, 3, '2026-07-01', '0000-00-00', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(18, 18, 1, 4, '2026-07-01', '0000-00-00', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(19, 19, 1, 5, '2026-07-01', '0000-00-00', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(20, 20, 1, 6, '2026-07-01', '0000-00-00', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(21, 21, 1, 7, '2026-07-01', '0000-00-00', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(22, 22, 1, 8, '2026-07-01', '0000-00-00', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(23, 23, 1, 9, '2026-07-01', '0000-00-00', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(24, 24, 1, 10, '2026-07-01', '0000-00-00', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(25, 25, 1, 11, '2026-07-01', '0000-00-00', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(26, 26, 1, 12, '2026-07-01', '0000-00-00', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(27, 27, 1, 13, '2026-07-01', '0000-00-00', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(28, 28, 1, 14, '2026-07-01', '0000-00-00', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(29, 29, 1, 1, '2026-07-01', '0000-00-00', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(30, 30, 1, 2, '2026-07-01', '0000-00-00', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(31, 31, 1, 3, '2026-07-01', '0000-00-00', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(32, 32, 1, 4, '2026-07-01', '0000-00-00', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(33, 33, 1, 5, '2026-07-01', '0000-00-00', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(34, 34, 1, 6, '2026-07-01', '0000-00-00', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(35, 35, 1, 7, '2026-07-01', '0000-00-00', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(36, 36, 1, 8, '2026-07-01', '0000-00-00', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(37, 37, 1, 9, '2026-07-01', '0000-00-00', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(38, 38, 1, 10, '2026-07-01', '0000-00-00', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(39, 39, 1, 11, '2026-07-01', '0000-00-00', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(40, 40, 1, 12, '2026-07-01', '0000-00-00', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(41, 41, 1, 13, '2026-07-01', '0000-00-00', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(42, 42, 1, 14, '2026-07-01', '0000-00-00', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(43, 43, 1, 1, '2026-07-01', '0000-00-00', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(44, 44, 1, 2, '2026-07-01', '0000-00-00', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(45, 45, 1, 3, '2026-07-01', '0000-00-00', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(46, 46, 1, 4, '2026-07-01', '0000-00-00', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(47, 47, 1, 5, '2026-07-01', '0000-00-00', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(48, 48, 1, 6, '2026-07-01', '0000-00-00', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(49, 49, 1, 7, '2026-07-01', '0000-00-00', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(50, 50, 1, 8, '2026-07-01', '0000-00-00', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(51, 51, 1, 9, '2026-07-01', '0000-00-00', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(52, 52, 1, 10, '2026-07-01', '0000-00-00', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(53, 53, 1, 11, '2026-07-01', '0000-00-00', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(54, 54, 1, 12, '2026-07-01', '0000-00-00', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(55, 55, 1, 13, '2026-07-01', '0000-00-00', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(56, 56, 1, 14, '2026-07-01', '0000-00-00', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(57, 57, 1, 1, '2026-07-01', '0000-00-00', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(58, 58, 1, 2, '2026-07-01', '0000-00-00', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(59, 59, 1, 3, '2026-07-01', '0000-00-00', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(60, 60, 1, 4, '2026-07-01', '0000-00-00', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(61, 61, 1, 5, '2026-07-01', '0000-00-00', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(62, 62, 1, 6, '2026-07-01', '0000-00-00', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(63, 63, 1, 7, '2026-07-01', '0000-00-00', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(64, 64, 1, 8, '2026-07-01', '0000-00-00', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(65, 65, 1, 9, '2026-07-01', '0000-00-00', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(66, 66, 1, 10, '2026-07-01', '0000-00-00', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(67, 67, 1, 11, '2026-07-01', '0000-00-00', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(68, 68, 1, 12, '2026-07-01', '0000-00-00', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(69, 69, 1, 13, '2026-07-01', '0000-00-00', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(70, 70, 1, 14, '2026-07-01', '0000-00-00', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(71, 71, 1, 1, '2026-07-01', '0000-00-00', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(72, 72, 1, 2, '2026-07-01', '0000-00-00', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(73, 73, 1, 3, '2026-07-01', '0000-00-00', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(74, 74, 1, 4, '2026-07-01', '0000-00-00', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(75, 75, 1, 5, '2026-07-01', '0000-00-00', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(76, 76, 1, 6, '2026-07-01', '0000-00-00', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(77, 77, 1, 7, '2026-07-01', '0000-00-00', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(78, 78, 1, 8, '2026-07-01', '0000-00-00', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(79, 79, 1, 9, '2026-07-01', '0000-00-00', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(80, 80, 1, 10, '2026-07-01', '0000-00-00', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(81, 81, 1, 11, '2026-07-01', '0000-00-00', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(82, 82, 1, 12, '2026-07-01', '0000-00-00', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(83, 83, 1, 13, '2026-07-01', '0000-00-00', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(84, 84, 1, 14, '2026-07-01', '0000-00-00', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(85, 85, 1, 1, '2026-07-01', '0000-00-00', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(86, 86, 1, 2, '2026-07-01', '0000-00-00', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(87, 87, 1, 3, '2026-07-01', '0000-00-00', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(88, 88, 1, 4, '2026-07-01', '0000-00-00', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(89, 89, 1, 5, '2026-07-01', '0000-00-00', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(90, 90, 1, 6, '2026-07-01', '0000-00-00', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(91, 91, 1, 7, '2026-07-01', '0000-00-00', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(92, 92, 1, 8, '2026-07-01', '0000-00-00', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(93, 93, 1, 9, '2026-07-01', '0000-00-00', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(94, 94, 1, 10, '2026-07-01', '0000-00-00', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(95, 95, 1, 11, '2026-07-01', '0000-00-00', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(96, 96, 1, 12, '2026-07-01', '0000-00-00', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(97, 97, 1, 13, '2026-07-01', '0000-00-00', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(98, 98, 1, 14, '2026-07-01', '0000-00-00', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(99, 99, 1, 1, '2026-07-01', '0000-00-00', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(100, 100, 1, 2, '2026-07-01', '0000-00-00', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_pelanggaran`
--

CREATE TABLE `t_pelanggaran` (
  `id` int(11) NOT NULL,
  `pelanggaran_kategori_id` int(11) DEFAULT NULL,
  `kode` varchar(30) DEFAULT NULL,
  `nama` varchar(150) DEFAULT NULL,
  `poin` int(11) NOT NULL,
  `deskripsi` text NOT NULL,
  `status_aktif` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `id_t_siswa` int(11) NOT NULL,
  `pelanggaran` varchar(255) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `status_tindakan` varchar(100) NOT NULL DEFAULT 'Perlu Tindakan'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_pelanggaran`
--

INSERT INTO `t_pelanggaran` (`id`, `pelanggaran_kategori_id`, `kode`, `nama`, `poin`, `deskripsi`, `status_aktif`, `created_at`, `updated_at`, `id_t_siswa`, `pelanggaran`, `tanggal`, `status_tindakan`) VALUES
(1, 1, 'PG-001', 'Terlambat datang ke sekolah #001', 2, 'Deskripsi pelanggaran nomor 1.', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(2, 2, 'PG-002', 'Tidak memakai atribut lengkap #002', 3, 'Deskripsi pelanggaran nomor 2.', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(3, 3, 'PG-003', 'Tidak memakai seragam sesuai ketentuan #003', 4, 'Deskripsi pelanggaran nomor 3.', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(4, 4, 'PG-004', 'Meninggalkan kelas tanpa izin #004', 5, 'Deskripsi pelanggaran nomor 4.', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(5, 5, 'PG-005', 'Tidak mengerjakan tugas #005', 6, 'Deskripsi pelanggaran nomor 5.', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(6, 6, 'PG-006', 'Rambut tidak sesuai aturan #006', 7, 'Deskripsi pelanggaran nomor 6.', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(7, 7, 'PG-007', 'Membawa barang terlarang #007', 8, 'Deskripsi pelanggaran nomor 7.', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(8, 8, 'PG-008', 'Berkata tidak sopan #008', 9, 'Deskripsi pelanggaran nomor 8.', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(9, 9, 'PG-009', 'Membuang sampah sembarangan #009', 10, 'Deskripsi pelanggaran nomor 9.', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(10, 10, 'PG-010', 'Tidak mengikuti upacara #010', 1, 'Deskripsi pelanggaran nomor 10.', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(11, 11, 'PG-011', 'Terlambat datang ke sekolah #011', 2, 'Deskripsi pelanggaran nomor 11.', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(12, 12, 'PG-012', 'Tidak memakai atribut lengkap #012', 3, 'Deskripsi pelanggaran nomor 12.', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(13, 13, 'PG-013', 'Tidak memakai seragam sesuai ketentuan #013', 4, 'Deskripsi pelanggaran nomor 13.', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(14, 14, 'PG-014', 'Meninggalkan kelas tanpa izin #014', 5, 'Deskripsi pelanggaran nomor 14.', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(15, 15, 'PG-015', 'Tidak mengerjakan tugas #015', 6, 'Deskripsi pelanggaran nomor 15.', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(16, 16, 'PG-016', 'Rambut tidak sesuai aturan #016', 7, 'Deskripsi pelanggaran nomor 16.', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(17, 17, 'PG-017', 'Membawa barang terlarang #017', 8, 'Deskripsi pelanggaran nomor 17.', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(18, 18, 'PG-018', 'Berkata tidak sopan #018', 9, 'Deskripsi pelanggaran nomor 18.', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(19, 19, 'PG-019', 'Membuang sampah sembarangan #019', 10, 'Deskripsi pelanggaran nomor 19.', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(20, 20, 'PG-020', 'Tidak mengikuti upacara #020', 1, 'Deskripsi pelanggaran nomor 20.', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(21, 21, 'PG-021', 'Terlambat datang ke sekolah #021', 2, 'Deskripsi pelanggaran nomor 21.', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(22, 22, 'PG-022', 'Tidak memakai atribut lengkap #022', 3, 'Deskripsi pelanggaran nomor 22.', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(23, 23, 'PG-023', 'Tidak memakai seragam sesuai ketentuan #023', 4, 'Deskripsi pelanggaran nomor 23.', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(24, 24, 'PG-024', 'Meninggalkan kelas tanpa izin #024', 5, 'Deskripsi pelanggaran nomor 24.', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(25, 25, 'PG-025', 'Tidak mengerjakan tugas #025', 6, 'Deskripsi pelanggaran nomor 25.', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(26, 26, 'PG-026', 'Rambut tidak sesuai aturan #026', 7, 'Deskripsi pelanggaran nomor 26.', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(27, 27, 'PG-027', 'Membawa barang terlarang #027', 8, 'Deskripsi pelanggaran nomor 27.', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(28, 28, 'PG-028', 'Berkata tidak sopan #028', 9, 'Deskripsi pelanggaran nomor 28.', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(29, 29, 'PG-029', 'Membuang sampah sembarangan #029', 10, 'Deskripsi pelanggaran nomor 29.', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(30, 30, 'PG-030', 'Tidak mengikuti upacara #030', 1, 'Deskripsi pelanggaran nomor 30.', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(31, 31, 'PG-031', 'Terlambat datang ke sekolah #031', 2, 'Deskripsi pelanggaran nomor 31.', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(32, 32, 'PG-032', 'Tidak memakai atribut lengkap #032', 3, 'Deskripsi pelanggaran nomor 32.', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(33, 33, 'PG-033', 'Tidak memakai seragam sesuai ketentuan #033', 4, 'Deskripsi pelanggaran nomor 33.', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(34, 34, 'PG-034', 'Meninggalkan kelas tanpa izin #034', 5, 'Deskripsi pelanggaran nomor 34.', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(35, 35, 'PG-035', 'Tidak mengerjakan tugas #035', 6, 'Deskripsi pelanggaran nomor 35.', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(36, 36, 'PG-036', 'Rambut tidak sesuai aturan #036', 7, 'Deskripsi pelanggaran nomor 36.', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(37, 37, 'PG-037', 'Membawa barang terlarang #037', 8, 'Deskripsi pelanggaran nomor 37.', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(38, 38, 'PG-038', 'Berkata tidak sopan #038', 9, 'Deskripsi pelanggaran nomor 38.', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(39, 39, 'PG-039', 'Membuang sampah sembarangan #039', 10, 'Deskripsi pelanggaran nomor 39.', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(40, 40, 'PG-040', 'Tidak mengikuti upacara #040', 1, 'Deskripsi pelanggaran nomor 40.', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(41, 41, 'PG-041', 'Terlambat datang ke sekolah #041', 2, 'Deskripsi pelanggaran nomor 41.', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(42, 42, 'PG-042', 'Tidak memakai atribut lengkap #042', 3, 'Deskripsi pelanggaran nomor 42.', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(43, 43, 'PG-043', 'Tidak memakai seragam sesuai ketentuan #043', 4, 'Deskripsi pelanggaran nomor 43.', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(44, 44, 'PG-044', 'Meninggalkan kelas tanpa izin #044', 5, 'Deskripsi pelanggaran nomor 44.', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(45, 45, 'PG-045', 'Tidak mengerjakan tugas #045', 6, 'Deskripsi pelanggaran nomor 45.', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(46, 46, 'PG-046', 'Rambut tidak sesuai aturan #046', 7, 'Deskripsi pelanggaran nomor 46.', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(47, 47, 'PG-047', 'Membawa barang terlarang #047', 8, 'Deskripsi pelanggaran nomor 47.', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(48, 48, 'PG-048', 'Berkata tidak sopan #048', 9, 'Deskripsi pelanggaran nomor 48.', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(49, 49, 'PG-049', 'Membuang sampah sembarangan #049', 10, 'Deskripsi pelanggaran nomor 49.', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(50, 50, 'PG-050', 'Tidak mengikuti upacara #050', 1, 'Deskripsi pelanggaran nomor 50.', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(51, 51, 'PG-051', 'Terlambat datang ke sekolah #051', 2, 'Deskripsi pelanggaran nomor 51.', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(52, 52, 'PG-052', 'Tidak memakai atribut lengkap #052', 3, 'Deskripsi pelanggaran nomor 52.', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(53, 53, 'PG-053', 'Tidak memakai seragam sesuai ketentuan #053', 4, 'Deskripsi pelanggaran nomor 53.', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(54, 54, 'PG-054', 'Meninggalkan kelas tanpa izin #054', 5, 'Deskripsi pelanggaran nomor 54.', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(55, 55, 'PG-055', 'Tidak mengerjakan tugas #055', 6, 'Deskripsi pelanggaran nomor 55.', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(56, 56, 'PG-056', 'Rambut tidak sesuai aturan #056', 7, 'Deskripsi pelanggaran nomor 56.', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(57, 57, 'PG-057', 'Membawa barang terlarang #057', 8, 'Deskripsi pelanggaran nomor 57.', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(58, 58, 'PG-058', 'Berkata tidak sopan #058', 9, 'Deskripsi pelanggaran nomor 58.', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(59, 59, 'PG-059', 'Membuang sampah sembarangan #059', 10, 'Deskripsi pelanggaran nomor 59.', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(60, 60, 'PG-060', 'Tidak mengikuti upacara #060', 1, 'Deskripsi pelanggaran nomor 60.', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(61, 61, 'PG-061', 'Terlambat datang ke sekolah #061', 2, 'Deskripsi pelanggaran nomor 61.', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(62, 62, 'PG-062', 'Tidak memakai atribut lengkap #062', 3, 'Deskripsi pelanggaran nomor 62.', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(63, 63, 'PG-063', 'Tidak memakai seragam sesuai ketentuan #063', 4, 'Deskripsi pelanggaran nomor 63.', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(64, 64, 'PG-064', 'Meninggalkan kelas tanpa izin #064', 5, 'Deskripsi pelanggaran nomor 64.', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(65, 65, 'PG-065', 'Tidak mengerjakan tugas #065', 6, 'Deskripsi pelanggaran nomor 65.', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(66, 66, 'PG-066', 'Rambut tidak sesuai aturan #066', 7, 'Deskripsi pelanggaran nomor 66.', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(67, 67, 'PG-067', 'Membawa barang terlarang #067', 8, 'Deskripsi pelanggaran nomor 67.', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(68, 68, 'PG-068', 'Berkata tidak sopan #068', 9, 'Deskripsi pelanggaran nomor 68.', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(69, 69, 'PG-069', 'Membuang sampah sembarangan #069', 10, 'Deskripsi pelanggaran nomor 69.', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(70, 70, 'PG-070', 'Tidak mengikuti upacara #070', 1, 'Deskripsi pelanggaran nomor 70.', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(71, 71, 'PG-071', 'Terlambat datang ke sekolah #071', 2, 'Deskripsi pelanggaran nomor 71.', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(72, 72, 'PG-072', 'Tidak memakai atribut lengkap #072', 3, 'Deskripsi pelanggaran nomor 72.', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(73, 73, 'PG-073', 'Tidak memakai seragam sesuai ketentuan #073', 4, 'Deskripsi pelanggaran nomor 73.', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(74, 74, 'PG-074', 'Meninggalkan kelas tanpa izin #074', 5, 'Deskripsi pelanggaran nomor 74.', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(75, 75, 'PG-075', 'Tidak mengerjakan tugas #075', 6, 'Deskripsi pelanggaran nomor 75.', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(76, 76, 'PG-076', 'Rambut tidak sesuai aturan #076', 7, 'Deskripsi pelanggaran nomor 76.', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(77, 77, 'PG-077', 'Membawa barang terlarang #077', 8, 'Deskripsi pelanggaran nomor 77.', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(78, 78, 'PG-078', 'Berkata tidak sopan #078', 9, 'Deskripsi pelanggaran nomor 78.', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(79, 79, 'PG-079', 'Membuang sampah sembarangan #079', 10, 'Deskripsi pelanggaran nomor 79.', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(80, 80, 'PG-080', 'Tidak mengikuti upacara #080', 1, 'Deskripsi pelanggaran nomor 80.', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(81, 81, 'PG-081', 'Terlambat datang ke sekolah #081', 2, 'Deskripsi pelanggaran nomor 81.', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(82, 82, 'PG-082', 'Tidak memakai atribut lengkap #082', 3, 'Deskripsi pelanggaran nomor 82.', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(83, 83, 'PG-083', 'Tidak memakai seragam sesuai ketentuan #083', 4, 'Deskripsi pelanggaran nomor 83.', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(84, 84, 'PG-084', 'Meninggalkan kelas tanpa izin #084', 5, 'Deskripsi pelanggaran nomor 84.', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(85, 85, 'PG-085', 'Tidak mengerjakan tugas #085', 6, 'Deskripsi pelanggaran nomor 85.', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(86, 86, 'PG-086', 'Rambut tidak sesuai aturan #086', 7, 'Deskripsi pelanggaran nomor 86.', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(87, 87, 'PG-087', 'Membawa barang terlarang #087', 8, 'Deskripsi pelanggaran nomor 87.', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(88, 88, 'PG-088', 'Berkata tidak sopan #088', 9, 'Deskripsi pelanggaran nomor 88.', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(89, 89, 'PG-089', 'Membuang sampah sembarangan #089', 10, 'Deskripsi pelanggaran nomor 89.', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(90, 90, 'PG-090', 'Tidak mengikuti upacara #090', 1, 'Deskripsi pelanggaran nomor 90.', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(91, 91, 'PG-091', 'Terlambat datang ke sekolah #091', 2, 'Deskripsi pelanggaran nomor 91.', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(92, 92, 'PG-092', 'Tidak memakai atribut lengkap #092', 3, 'Deskripsi pelanggaran nomor 92.', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(93, 93, 'PG-093', 'Tidak memakai seragam sesuai ketentuan #093', 4, 'Deskripsi pelanggaran nomor 93.', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(94, 94, 'PG-094', 'Meninggalkan kelas tanpa izin #094', 5, 'Deskripsi pelanggaran nomor 94.', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(95, 95, 'PG-095', 'Tidak mengerjakan tugas #095', 6, 'Deskripsi pelanggaran nomor 95.', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(96, 96, 'PG-096', 'Rambut tidak sesuai aturan #096', 7, 'Deskripsi pelanggaran nomor 96.', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(97, 97, 'PG-097', 'Membawa barang terlarang #097', 8, 'Deskripsi pelanggaran nomor 97.', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(98, 98, 'PG-098', 'Berkata tidak sopan #098', 9, 'Deskripsi pelanggaran nomor 98.', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(99, 99, 'PG-099', 'Membuang sampah sembarangan #099', 10, 'Deskripsi pelanggaran nomor 99.', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(100, 100, 'PG-100', 'Tidak mengikuti upacara #100', 1, 'Deskripsi pelanggaran nomor 100.', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00', 0, '', NULL, 'Perlu Tindakan'),
(101, NULL, NULL, NULL, 12, '', 0, '2026-10-21 05:24:29', '2026-10-21 05:24:29', 91, 'terlambat', '2026-10-21', 'Sudah Ditindak'),
(102, NULL, NULL, NULL, 1, '', 0, '2026-10-21 05:26:21', '2026-10-21 05:26:21', 39, 'makan di kelas', '2026-10-21', 'Sudah Ditindak'),
(103, NULL, NULL, NULL, 10, '', 0, '2026-11-10 07:42:04', '2026-11-10 07:42:04', 1, 'tidur di kelas', '2026-11-10', 'Sudah Ditindak'),
(104, NULL, NULL, NULL, 8, '', 0, '2026-11-11 04:55:25', '2026-11-11 04:55:25', 22, 'Membawa barang terlarang #007', '2026-11-11', 'Sudah Ditindak'),
(105, NULL, NULL, NULL, 9, '', 0, '2026-11-11 04:56:15', '2026-11-11 04:56:15', 20, 'Berkata tidak sopan #008', '2026-11-11', 'Sudah Ditindak'),
(106, NULL, NULL, NULL, 8, '', 0, '2026-11-11 05:18:17', '2026-11-11 05:18:17', 121, 'Membawa barang terlarang #017', '2026-11-11', 'Sudah Ditindak'),
(107, NULL, NULL, NULL, 20, '', 0, '2026-11-11 05:28:09', '2026-11-11 05:28:09', 121, 'Membawa Barang Terlarang', '2026-11-11', 'Perlu Tindakan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_pelanggaran_kategori`
--

CREATE TABLE `t_pelanggaran_kategori` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `deskripsi` text NOT NULL,
  `status_aktif` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_pelanggaran_kategori`
--

INSERT INTO `t_pelanggaran_kategori` (`id`, `nama`, `deskripsi`, `status_aktif`, `created_at`, `updated_at`) VALUES
(1, 'Kedisiplinan 1', 'Kategori pelanggaran nomor 1', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(2, 'Kerapian 1', 'Kategori pelanggaran nomor 2', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(3, 'Kehadiran 1', 'Kategori pelanggaran nomor 3', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(4, 'Ketertiban 1', 'Kategori pelanggaran nomor 4', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(5, 'Perlengkapan 1', 'Kategori pelanggaran nomor 5', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(6, 'Sikap 1', 'Kategori pelanggaran nomor 6', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(7, 'Kebersihan 1', 'Kategori pelanggaran nomor 7', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(8, 'Keamanan 1', 'Kategori pelanggaran nomor 8', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(9, 'Akademik 1', 'Kategori pelanggaran nomor 9', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(10, 'Lingkungan 1', 'Kategori pelanggaran nomor 10', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(11, 'Kedisiplinan 2', 'Kategori pelanggaran nomor 11', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(12, 'Kerapian 2', 'Kategori pelanggaran nomor 12', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(13, 'Kehadiran 2', 'Kategori pelanggaran nomor 13', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(14, 'Ketertiban 2', 'Kategori pelanggaran nomor 14', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(15, 'Perlengkapan 2', 'Kategori pelanggaran nomor 15', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(16, 'Sikap 2', 'Kategori pelanggaran nomor 16', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(17, 'Kebersihan 2', 'Kategori pelanggaran nomor 17', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(18, 'Keamanan 2', 'Kategori pelanggaran nomor 18', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(19, 'Akademik 2', 'Kategori pelanggaran nomor 19', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(20, 'Lingkungan 2', 'Kategori pelanggaran nomor 20', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(21, 'Kedisiplinan 3', 'Kategori pelanggaran nomor 21', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(22, 'Kerapian 3', 'Kategori pelanggaran nomor 22', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(23, 'Kehadiran 3', 'Kategori pelanggaran nomor 23', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(24, 'Ketertiban 3', 'Kategori pelanggaran nomor 24', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(25, 'Perlengkapan 3', 'Kategori pelanggaran nomor 25', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(26, 'Sikap 3', 'Kategori pelanggaran nomor 26', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(27, 'Kebersihan 3', 'Kategori pelanggaran nomor 27', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(28, 'Keamanan 3', 'Kategori pelanggaran nomor 28', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(29, 'Akademik 3', 'Kategori pelanggaran nomor 29', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(30, 'Lingkungan 3', 'Kategori pelanggaran nomor 30', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(31, 'Kedisiplinan 4', 'Kategori pelanggaran nomor 31', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(32, 'Kerapian 4', 'Kategori pelanggaran nomor 32', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(33, 'Kehadiran 4', 'Kategori pelanggaran nomor 33', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(34, 'Ketertiban 4', 'Kategori pelanggaran nomor 34', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(35, 'Perlengkapan 4', 'Kategori pelanggaran nomor 35', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(36, 'Sikap 4', 'Kategori pelanggaran nomor 36', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(37, 'Kebersihan 4', 'Kategori pelanggaran nomor 37', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(38, 'Keamanan 4', 'Kategori pelanggaran nomor 38', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(39, 'Akademik 4', 'Kategori pelanggaran nomor 39', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(40, 'Lingkungan 4', 'Kategori pelanggaran nomor 40', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(41, 'Kedisiplinan 5', 'Kategori pelanggaran nomor 41', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(42, 'Kerapian 5', 'Kategori pelanggaran nomor 42', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(43, 'Kehadiran 5', 'Kategori pelanggaran nomor 43', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(44, 'Ketertiban 5', 'Kategori pelanggaran nomor 44', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(45, 'Perlengkapan 5', 'Kategori pelanggaran nomor 45', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(46, 'Sikap 5', 'Kategori pelanggaran nomor 46', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(47, 'Kebersihan 5', 'Kategori pelanggaran nomor 47', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(48, 'Keamanan 5', 'Kategori pelanggaran nomor 48', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(49, 'Akademik 5', 'Kategori pelanggaran nomor 49', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(50, 'Lingkungan 5', 'Kategori pelanggaran nomor 50', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(51, 'Kedisiplinan 6', 'Kategori pelanggaran nomor 51', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(52, 'Kerapian 6', 'Kategori pelanggaran nomor 52', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(53, 'Kehadiran 6', 'Kategori pelanggaran nomor 53', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(54, 'Ketertiban 6', 'Kategori pelanggaran nomor 54', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(55, 'Perlengkapan 6', 'Kategori pelanggaran nomor 55', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(56, 'Sikap 6', 'Kategori pelanggaran nomor 56', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(57, 'Kebersihan 6', 'Kategori pelanggaran nomor 57', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(58, 'Keamanan 6', 'Kategori pelanggaran nomor 58', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(59, 'Akademik 6', 'Kategori pelanggaran nomor 59', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(60, 'Lingkungan 6', 'Kategori pelanggaran nomor 60', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(61, 'Kedisiplinan 7', 'Kategori pelanggaran nomor 61', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(62, 'Kerapian 7', 'Kategori pelanggaran nomor 62', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(63, 'Kehadiran 7', 'Kategori pelanggaran nomor 63', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(64, 'Ketertiban 7', 'Kategori pelanggaran nomor 64', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(65, 'Perlengkapan 7', 'Kategori pelanggaran nomor 65', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(66, 'Sikap 7', 'Kategori pelanggaran nomor 66', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(67, 'Kebersihan 7', 'Kategori pelanggaran nomor 67', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(68, 'Keamanan 7', 'Kategori pelanggaran nomor 68', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(69, 'Akademik 7', 'Kategori pelanggaran nomor 69', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(70, 'Lingkungan 7', 'Kategori pelanggaran nomor 70', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(71, 'Kedisiplinan 8', 'Kategori pelanggaran nomor 71', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(72, 'Kerapian 8', 'Kategori pelanggaran nomor 72', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(73, 'Kehadiran 8', 'Kategori pelanggaran nomor 73', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(74, 'Ketertiban 8', 'Kategori pelanggaran nomor 74', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(75, 'Perlengkapan 8', 'Kategori pelanggaran nomor 75', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(76, 'Sikap 8', 'Kategori pelanggaran nomor 76', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(77, 'Kebersihan 8', 'Kategori pelanggaran nomor 77', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(78, 'Keamanan 8', 'Kategori pelanggaran nomor 78', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(79, 'Akademik 8', 'Kategori pelanggaran nomor 79', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(80, 'Lingkungan 8', 'Kategori pelanggaran nomor 80', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(81, 'Kedisiplinan 9', 'Kategori pelanggaran nomor 81', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(82, 'Kerapian 9', 'Kategori pelanggaran nomor 82', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(83, 'Kehadiran 9', 'Kategori pelanggaran nomor 83', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(84, 'Ketertiban 9', 'Kategori pelanggaran nomor 84', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(85, 'Perlengkapan 9', 'Kategori pelanggaran nomor 85', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(86, 'Sikap 9', 'Kategori pelanggaran nomor 86', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(87, 'Kebersihan 9', 'Kategori pelanggaran nomor 87', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(88, 'Keamanan 9', 'Kategori pelanggaran nomor 88', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(89, 'Akademik 9', 'Kategori pelanggaran nomor 89', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(90, 'Lingkungan 9', 'Kategori pelanggaran nomor 90', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(91, 'Kedisiplinan 10', 'Kategori pelanggaran nomor 91', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(92, 'Kerapian 10', 'Kategori pelanggaran nomor 92', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(93, 'Kehadiran 10', 'Kategori pelanggaran nomor 93', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(94, 'Ketertiban 10', 'Kategori pelanggaran nomor 94', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(95, 'Perlengkapan 10', 'Kategori pelanggaran nomor 95', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(96, 'Sikap 10', 'Kategori pelanggaran nomor 96', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(97, 'Kebersihan 10', 'Kategori pelanggaran nomor 97', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(98, 'Keamanan 10', 'Kategori pelanggaran nomor 98', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(99, 'Akademik 10', 'Kategori pelanggaran nomor 99', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(100, 'Lingkungan 10', 'Kategori pelanggaran nomor 100', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_pelanggaran_siswa`
--

CREATE TABLE `t_pelanggaran_siswa` (
  `id` int(11) NOT NULL,
  `tahun_ajaran_id` int(11) DEFAULT NULL,
  `siswa_id` int(11) DEFAULT NULL,
  `nama_siswa` varchar(150) NOT NULL,
  `kelas_id` int(11) DEFAULT NULL,
  `nama_kelas` varchar(100) NOT NULL,
  `pelanggaran_id` int(11) DEFAULT NULL,
  `nama_pelanggaran` varchar(150) NOT NULL,
  `pelanggaran_kategori_id` int(11) DEFAULT NULL,
  `guru_id` int(11) DEFAULT NULL,
  `nama_guru` varchar(150) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `keterangan` text NOT NULL,
  `poin` int(11) NOT NULL,
  `tindakan` text NOT NULL,
  `status` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_pelanggaran_siswa`
--

INSERT INTO `t_pelanggaran_siswa` (`id`, `tahun_ajaran_id`, `siswa_id`, `nama_siswa`, `kelas_id`, `nama_kelas`, `pelanggaran_id`, `nama_pelanggaran`, `pelanggaran_kategori_id`, `guru_id`, `nama_guru`, `tanggal`, `keterangan`, `poin`, `tindakan`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Siswa 1', 1, 'BD', 1, 'Datang terlambat', 1, 1, 'Ahmad Hidayat', '2026-07-01', 'Pencatatan pelanggaran siswa', 5, 'Teguran lisan', 'tercatat', '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(2, 1, 2, 'Siswa 2', 2, 'TSM 1', 2, 'Tidak memakai atribut lengkap', 2, 2, 'Budi Santoso', '2026-07-02', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(3, 1, 3, 'Siswa 3', 3, 'TSM 2', 3, 'Tidak mengerjakan tugas', 3, 3, 'Citra Lestari', '2026-07-03', 'Pencatatan pelanggaran siswa', 15, 'Pemanggilan siswa', 'tercatat', '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(4, 1, 4, 'Siswa 4', 4, 'TSM 3', 4, 'Keluar kelas tanpa izin', 4, 4, 'Dedi Kurniawan', '2026-07-04', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan', 'tercatat', '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(5, 1, 5, 'Siswa 5', 5, 'RPL 1', 5, 'Tidak mengikuti upacara', 5, 5, 'Eka Wulandari', '2026-07-05', 'Pencatatan pelanggaran siswa', 15, 'Teguran lisan', 'tercatat', '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(6, 1, 6, 'Siswa 6', 6, 'RPL 2', 6, 'Membawa barang terlarang', 6, 6, 'Fajar Nugraha', '2026-07-06', 'Pencatatan pelanggaran siswa', 20, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(7, 1, 7, 'Siswa 7', 7, 'TKJ 1', 7, 'Berbicara saat pembelajaran', 7, 7, 'Gina Permata', '2026-07-07', 'Pencatatan pelanggaran siswa', 5, 'Pemanggilan siswa', 'tercatat', '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(8, 1, 8, 'Siswa 8', 8, 'TKJ 2', 8, 'Tidak menjaga kebersihan kelas', 8, 8, 'Hendra Wijaya', '2026-07-08', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan', 'tercatat', '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(9, 1, 9, 'Siswa 9', 9, 'TKJ 3', 9, 'Mengganggu kegiatan belajar', 9, 9, 'Indah Sari', '2026-07-09', 'Pencatatan pelanggaran siswa', 10, 'Teguran lisan', 'tercatat', '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(10, 1, 10, 'Siswa 10', 10, 'TKJ 4', 10, 'Tidak mengikuti pembelajaran', 10, 10, 'Joko Susanto', '2026-07-10', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(11, 1, 11, 'Siswa 11', 11, 'TKR 1', 11, 'Datang terlambat', 11, 11, 'Kartika Dewi', '2026-07-11', 'Pencatatan pelanggaran siswa', 5, 'Pemanggilan siswa', 'tercatat', '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(12, 1, 12, 'Siswa 12', 12, 'TKR 2', 12, 'Tidak memakai atribut lengkap', 12, 12, 'Lukman Hakim', '2026-07-12', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan', 'tercatat', '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(13, 1, 13, 'Siswa 13', 13, 'TKR 3', 13, 'Tidak mengerjakan tugas', 13, 13, 'Maya Sari', '2026-07-13', 'Pencatatan pelanggaran siswa', 15, 'Teguran lisan', 'tercatat', '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(14, 1, 14, 'Siswa 14', 14, 'TKR 4', 14, 'Keluar kelas tanpa izin', 14, 14, 'Nanda Saputra', '2026-07-14', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(15, 1, 15, 'Siswa 15', 15, 'BD', 15, 'Tidak mengikuti upacara', 15, 15, 'Olivia Putri', '2026-07-15', 'Pencatatan pelanggaran siswa', 15, 'Pemanggilan siswa', 'tercatat', '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(16, 1, 16, 'Siswa 16', 16, 'TSM 1', 16, 'Membawa barang terlarang', 16, 16, 'Pandu Setiawan', '2026-07-16', 'Pencatatan pelanggaran siswa', 20, 'Pembinaan', 'tercatat', '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(17, 1, 17, 'Siswa 17', 17, 'TSM 2', 17, 'Berbicara saat pembelajaran', 17, 17, 'Qori Ananda', '2026-07-17', 'Pencatatan pelanggaran siswa', 5, 'Teguran lisan', 'tercatat', '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(18, 1, 18, 'Siswa 18', 18, 'TSM 3', 18, 'Tidak menjaga kebersihan kelas', 18, 18, 'Rudi Hartono', '2026-07-18', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(19, 1, 19, 'Siswa 19', 19, 'RPL 1', 19, 'Mengganggu kegiatan belajar', 19, 19, 'Siti Rahma', '2026-07-19', 'Pencatatan pelanggaran siswa', 10, 'Pemanggilan siswa', 'tercatat', '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(20, 1, 20, 'Siswa 20', 20, 'RPL 2', 20, 'Tidak mengikuti pembelajaran', 20, 20, 'Taufik Hidayat', '2026-07-20', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan', 'tercatat', '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(21, 1, 21, 'Siswa 21', 21, 'TKJ 1', 21, 'Datang terlambat', 21, 21, 'Umi Kalsum', '2026-07-21', 'Pencatatan pelanggaran siswa', 5, 'Teguran lisan', 'tercatat', '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(22, 1, 22, 'Siswa 22', 22, 'TKJ 2', 22, 'Tidak memakai atribut lengkap', 22, 22, 'Vina Maharani', '2026-07-22', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(23, 1, 23, 'Siswa 23', 23, 'TKJ 3', 23, 'Tidak mengerjakan tugas', 23, 23, 'Wahyu Ramadhan', '2026-07-23', 'Pencatatan pelanggaran siswa', 15, 'Pemanggilan siswa', 'tercatat', '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(24, 1, 24, 'Siswa 24', 24, 'TKJ 4', 24, 'Keluar kelas tanpa izin', 24, 24, 'Yuni Astuti', '2026-07-24', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan', 'tercatat', '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(25, 1, 25, 'Siswa 25', 25, 'TKR 1', 25, 'Tidak mengikuti upacara', 25, 25, 'Zainal Abidin', '2026-07-25', 'Pencatatan pelanggaran siswa', 15, 'Teguran lisan', 'tercatat', '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(26, 1, 26, 'Siswa 26', 26, 'TKR 2', 26, 'Membawa barang terlarang', 26, 26, 'Agus Setiawan', '2026-07-26', 'Pencatatan pelanggaran siswa', 20, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(27, 1, 27, 'Siswa 27', 27, 'TKR 3', 27, 'Berbicara saat pembelajaran', 27, 27, 'Bella Anggraini', '2026-07-27', 'Pencatatan pelanggaran siswa', 5, 'Pemanggilan siswa', 'tercatat', '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(28, 1, 28, 'Siswa 28', 28, 'TKR 4', 28, 'Tidak menjaga kebersihan kelas', 28, 28, 'Cahyo Pratama', '2026-07-28', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan', 'tercatat', '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(29, 1, 29, 'Siswa 29', 29, 'BD', 29, 'Mengganggu kegiatan belajar', 29, 29, 'Dian Puspita', '2026-07-29', 'Pencatatan pelanggaran siswa', 10, 'Teguran lisan', 'tercatat', '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(30, 1, 30, 'Siswa 30', 30, 'TSM 1', 30, 'Tidak mengikuti pembelajaran', 30, 30, 'Eko Prasetyo', '2026-07-30', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(31, 1, 31, 'Siswa 31', 31, 'TSM 2', 31, 'Datang terlambat', 31, 31, 'Fitria Ningsih', '2026-07-31', 'Pencatatan pelanggaran siswa', 5, 'Pemanggilan siswa', 'tercatat', '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(32, 1, 32, 'Siswa 32', 32, 'TSM 3', 32, 'Tidak memakai atribut lengkap', 32, 32, 'Galih Firmansyah', '2026-07-01', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan', 'tercatat', '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(33, 1, 33, 'Siswa 33', 33, 'RPL 1', 33, 'Tidak mengerjakan tugas', 33, 33, 'Hani Marlina', '2026-07-02', 'Pencatatan pelanggaran siswa', 15, 'Teguran lisan', 'tercatat', '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(34, 1, 34, 'Siswa 34', 34, 'RPL 2', 34, 'Keluar kelas tanpa izin', 34, 34, 'Irwan Maulana', '2026-07-03', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(35, 1, 35, 'Siswa 35', 35, 'TKJ 1', 35, 'Tidak mengikuti upacara', 35, 35, 'Jihan Safitri', '2026-07-04', 'Pencatatan pelanggaran siswa', 15, 'Pemanggilan siswa', 'tercatat', '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(36, 1, 36, 'Siswa 36', 36, 'TKJ 2', 36, 'Membawa barang terlarang', 36, 36, 'Kurniawan Dwi', '2026-07-05', 'Pencatatan pelanggaran siswa', 20, 'Pembinaan', 'tercatat', '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(37, 1, 37, 'Siswa 37', 37, 'TKJ 3', 37, 'Berbicara saat pembelajaran', 37, 37, 'Lilis Karlina', '2026-07-06', 'Pencatatan pelanggaran siswa', 5, 'Teguran lisan', 'tercatat', '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(38, 1, 38, 'Siswa 38', 38, 'TKJ 4', 38, 'Tidak menjaga kebersihan kelas', 38, 38, 'Maman Suherman', '2026-07-07', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(39, 1, 39, 'Siswa 39', 39, 'TKR 1', 39, 'Mengganggu kegiatan belajar', 39, 39, 'Nia Ramadhani', '2026-07-08', 'Pencatatan pelanggaran siswa', 10, 'Pemanggilan siswa', 'tercatat', '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(40, 1, 40, 'Siswa 40', 40, 'TKR 2', 40, 'Tidak mengikuti pembelajaran', 40, 40, 'Oki Setiawan', '2026-07-09', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan', 'tercatat', '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(41, 1, 41, 'Siswa 41', 41, 'TKR 3', 41, 'Datang terlambat', 41, 41, 'Putri Amelia', '2026-07-10', 'Pencatatan pelanggaran siswa', 5, 'Teguran lisan', 'tercatat', '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(42, 1, 42, 'Siswa 42', 42, 'TKR 4', 42, 'Tidak memakai atribut lengkap', 42, 42, 'Rian Kurnia', '2026-07-11', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(43, 1, 43, 'Siswa 43', 43, 'BD', 43, 'Tidak mengerjakan tugas', 43, 43, 'Salsa Nabila', '2026-07-12', 'Pencatatan pelanggaran siswa', 15, 'Pemanggilan siswa', 'tercatat', '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(44, 1, 44, 'Siswa 44', 44, 'TSM 1', 44, 'Keluar kelas tanpa izin', 44, 44, 'Teguh Prakoso', '2026-07-13', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan', 'tercatat', '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(45, 1, 45, 'Siswa 45', 45, 'TSM 2', 45, 'Tidak mengikuti upacara', 45, 45, 'Utami Sari', '2026-07-14', 'Pencatatan pelanggaran siswa', 15, 'Teguran lisan', 'tercatat', '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(46, 1, 46, 'Siswa 46', 46, 'TSM 3', 46, 'Membawa barang terlarang', 46, 46, 'Vicky Ramadhan', '2026-07-15', 'Pencatatan pelanggaran siswa', 20, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(47, 1, 47, 'Siswa 47', 47, 'RPL 1', 47, 'Berbicara saat pembelajaran', 47, 47, 'Wulan Pertiwi', '2026-07-16', 'Pencatatan pelanggaran siswa', 5, 'Pemanggilan siswa', 'tercatat', '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(48, 1, 48, 'Siswa 48', 48, 'RPL 2', 48, 'Tidak menjaga kebersihan kelas', 48, 48, 'Yusuf Maulana', '2026-07-17', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan', 'tercatat', '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(49, 1, 49, 'Siswa 49', 49, 'TKJ 1', 49, 'Mengganggu kegiatan belajar', 49, 49, 'Zahra Aulia', '2026-07-18', 'Pencatatan pelanggaran siswa', 10, 'Teguran lisan', 'tercatat', '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(50, 1, 50, 'Siswa 50', 50, 'TKJ 2', 50, 'Tidak mengikuti pembelajaran', 50, 50, 'Andi Firmansyah', '2026-07-19', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(51, 1, 51, 'Siswa 51', 51, 'TKJ 3', 51, 'Datang terlambat', 51, 1, 'Ahmad Hidayat', '2026-07-20', 'Pencatatan pelanggaran siswa', 5, 'Pemanggilan siswa', 'tercatat', '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(52, 1, 52, 'Siswa 52', 52, 'TKJ 4', 52, 'Tidak memakai atribut lengkap', 52, 2, 'Budi Santoso', '2026-07-21', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan', 'tercatat', '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(53, 1, 53, 'Siswa 53', 53, 'TKR 1', 53, 'Tidak mengerjakan tugas', 53, 3, 'Citra Lestari', '2026-07-22', 'Pencatatan pelanggaran siswa', 15, 'Teguran lisan', 'tercatat', '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(54, 1, 54, 'Siswa 54', 54, 'TKR 2', 54, 'Keluar kelas tanpa izin', 54, 4, 'Dedi Kurniawan', '2026-07-23', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(55, 1, 55, 'Siswa 55', 55, 'TKR 3', 55, 'Tidak mengikuti upacara', 55, 5, 'Eka Wulandari', '2026-07-24', 'Pencatatan pelanggaran siswa', 15, 'Pemanggilan siswa', 'tercatat', '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(56, 1, 56, 'Siswa 56', 56, 'TKR 4', 56, 'Membawa barang terlarang', 56, 6, 'Fajar Nugraha', '2026-07-25', 'Pencatatan pelanggaran siswa', 20, 'Pembinaan', 'tercatat', '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(57, 1, 57, 'Siswa 57', 57, 'BD', 57, 'Berbicara saat pembelajaran', 57, 7, 'Gina Permata', '2026-07-26', 'Pencatatan pelanggaran siswa', 5, 'Teguran lisan', 'tercatat', '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(58, 1, 58, 'Siswa 58', 58, 'TSM 1', 58, 'Tidak menjaga kebersihan kelas', 58, 8, 'Hendra Wijaya', '2026-07-27', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(59, 1, 59, 'Siswa 59', 59, 'TSM 2', 59, 'Mengganggu kegiatan belajar', 59, 9, 'Indah Sari', '2026-07-28', 'Pencatatan pelanggaran siswa', 10, 'Pemanggilan siswa', 'tercatat', '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(60, 1, 60, 'Siswa 60', 60, 'TSM 3', 60, 'Tidak mengikuti pembelajaran', 60, 10, 'Joko Susanto', '2026-07-29', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan', 'tercatat', '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(61, 1, 61, 'Siswa 61', 61, 'RPL 1', 61, 'Datang terlambat', 61, 11, 'Kartika Dewi', '2026-07-30', 'Pencatatan pelanggaran siswa', 5, 'Teguran lisan', 'tercatat', '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(62, 1, 62, 'Siswa 62', 62, 'RPL 2', 62, 'Tidak memakai atribut lengkap', 62, 12, 'Lukman Hakim', '2026-07-31', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(63, 1, 63, 'Siswa 63', 63, 'TKJ 1', 63, 'Tidak mengerjakan tugas', 63, 13, 'Maya Sari', '2026-07-01', 'Pencatatan pelanggaran siswa', 15, 'Pemanggilan siswa', 'tercatat', '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(64, 1, 64, 'Siswa 64', 64, 'TKJ 2', 64, 'Keluar kelas tanpa izin', 64, 14, 'Nanda Saputra', '2026-07-02', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan', 'tercatat', '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(65, 1, 65, 'Siswa 65', 65, 'TKJ 3', 65, 'Tidak mengikuti upacara', 65, 15, 'Olivia Putri', '2026-07-03', 'Pencatatan pelanggaran siswa', 15, 'Teguran lisan', 'tercatat', '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(66, 1, 66, 'Siswa 66', 66, 'TKJ 4', 66, 'Membawa barang terlarang', 66, 16, 'Pandu Setiawan', '2026-07-04', 'Pencatatan pelanggaran siswa', 20, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(67, 1, 67, 'Siswa 67', 67, 'TKR 1', 67, 'Berbicara saat pembelajaran', 67, 17, 'Qori Ananda', '2026-07-05', 'Pencatatan pelanggaran siswa', 5, 'Pemanggilan siswa', 'tercatat', '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(68, 1, 68, 'Siswa 68', 68, 'TKR 2', 68, 'Tidak menjaga kebersihan kelas', 68, 18, 'Rudi Hartono', '2026-07-06', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan', 'tercatat', '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(69, 1, 69, 'Siswa 69', 69, 'TKR 3', 69, 'Mengganggu kegiatan belajar', 69, 19, 'Siti Rahma', '2026-07-07', 'Pencatatan pelanggaran siswa', 10, 'Teguran lisan', 'tercatat', '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(70, 1, 70, 'Siswa 70', 70, 'TKR 4', 70, 'Tidak mengikuti pembelajaran', 70, 20, 'Taufik Hidayat', '2026-07-08', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(71, 1, 71, 'Siswa 71', 71, 'BD', 71, 'Datang terlambat', 71, 21, 'Umi Kalsum', '2026-07-09', 'Pencatatan pelanggaran siswa', 5, 'Pemanggilan siswa', 'tercatat', '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(72, 1, 72, 'Siswa 72', 72, 'TSM 1', 72, 'Tidak memakai atribut lengkap', 72, 22, 'Vina Maharani', '2026-07-10', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan', 'tercatat', '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(73, 1, 73, 'Siswa 73', 73, 'TSM 2', 73, 'Tidak mengerjakan tugas', 73, 23, 'Wahyu Ramadhan', '2026-07-11', 'Pencatatan pelanggaran siswa', 15, 'Teguran lisan', 'tercatat', '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(74, 1, 74, 'Siswa 74', 74, 'TSM 3', 74, 'Keluar kelas tanpa izin', 74, 24, 'Yuni Astuti', '2026-07-12', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(75, 1, 75, 'Siswa 75', 75, 'RPL 1', 75, 'Tidak mengikuti upacara', 75, 25, 'Zainal Abidin', '2026-07-13', 'Pencatatan pelanggaran siswa', 15, 'Pemanggilan siswa', 'tercatat', '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(76, 1, 76, 'Siswa 76', 76, 'RPL 2', 76, 'Membawa barang terlarang', 76, 26, 'Agus Setiawan', '2026-07-14', 'Pencatatan pelanggaran siswa', 20, 'Pembinaan', 'tercatat', '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(77, 1, 77, 'Siswa 77', 77, 'TKJ 1', 77, 'Berbicara saat pembelajaran', 77, 27, 'Bella Anggraini', '2026-07-15', 'Pencatatan pelanggaran siswa', 5, 'Teguran lisan', 'tercatat', '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(78, 1, 78, 'Siswa 78', 78, 'TKJ 2', 78, 'Tidak menjaga kebersihan kelas', 78, 28, 'Cahyo Pratama', '2026-07-16', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(79, 1, 79, 'Siswa 79', 79, 'TKJ 3', 79, 'Mengganggu kegiatan belajar', 79, 29, 'Dian Puspita', '2026-07-17', 'Pencatatan pelanggaran siswa', 10, 'Pemanggilan siswa', 'tercatat', '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(80, 1, 80, 'Siswa 80', 80, 'TKJ 4', 80, 'Tidak mengikuti pembelajaran', 80, 30, 'Eko Prasetyo', '2026-07-18', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan', 'tercatat', '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(81, 1, 81, 'Siswa 81', 81, 'TKR 1', 81, 'Datang terlambat', 81, 31, 'Fitria Ningsih', '2026-07-19', 'Pencatatan pelanggaran siswa', 5, 'Teguran lisan', 'tercatat', '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(82, 1, 82, 'Siswa 82', 82, 'TKR 2', 82, 'Tidak memakai atribut lengkap', 82, 32, 'Galih Firmansyah', '2026-07-20', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(83, 1, 83, 'Siswa 83', 83, 'TKR 3', 83, 'Tidak mengerjakan tugas', 83, 33, 'Hani Marlina', '2026-07-21', 'Pencatatan pelanggaran siswa', 15, 'Pemanggilan siswa', 'tercatat', '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(84, 1, 84, 'Siswa 84', 84, 'TKR 4', 84, 'Keluar kelas tanpa izin', 84, 34, 'Irwan Maulana', '2026-07-22', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan', 'tercatat', '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(85, 1, 85, 'Siswa 85', 85, 'BD', 85, 'Tidak mengikuti upacara', 85, 35, 'Jihan Safitri', '2026-07-23', 'Pencatatan pelanggaran siswa', 15, 'Teguran lisan', 'tercatat', '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(86, 1, 86, 'Siswa 86', 86, 'TSM 1', 86, 'Membawa barang terlarang', 86, 36, 'Kurniawan Dwi', '2026-07-24', 'Pencatatan pelanggaran siswa', 20, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(87, 1, 87, 'Siswa 87', 87, 'TSM 2', 87, 'Berbicara saat pembelajaran', 87, 37, 'Lilis Karlina', '2026-07-25', 'Pencatatan pelanggaran siswa', 5, 'Pemanggilan siswa', 'tercatat', '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(88, 1, 88, 'Siswa 88', 88, 'TSM 3', 88, 'Tidak menjaga kebersihan kelas', 88, 38, 'Maman Suherman', '2026-07-26', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan', 'tercatat', '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(89, 1, 89, 'Siswa 89', 89, 'RPL 1', 89, 'Mengganggu kegiatan belajar', 89, 39, 'Nia Ramadhani', '2026-07-27', 'Pencatatan pelanggaran siswa', 10, 'Teguran lisan', 'tercatat', '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(90, 1, 90, 'Siswa 90', 90, 'RPL 2', 90, 'Tidak mengikuti pembelajaran', 90, 40, 'Oki Setiawan', '2026-07-28', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(91, 1, 91, 'Siswa 91', 91, 'TKJ 1', 91, 'Datang terlambat', 91, 41, 'Putri Amelia', '2026-07-29', 'Pencatatan pelanggaran siswa', 5, 'Pemanggilan siswa', 'tercatat', '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(92, 1, 92, 'Siswa 92', 92, 'TKJ 2', 92, 'Tidak memakai atribut lengkap', 92, 42, 'Rian Kurnia', '2026-07-30', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan', 'tercatat', '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(93, 1, 93, 'Siswa 93', 93, 'TKJ 3', 93, 'Tidak mengerjakan tugas', 93, 43, 'Salsa Nabila', '2026-07-31', 'Pencatatan pelanggaran siswa', 15, 'Teguran lisan', 'tercatat', '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(94, 1, 94, 'Siswa 94', 94, 'TKJ 4', 94, 'Keluar kelas tanpa izin', 94, 44, 'Teguh Prakoso', '2026-07-01', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(95, 1, 95, 'Siswa 95', 95, 'TKR 1', 95, 'Tidak mengikuti upacara', 95, 45, 'Utami Sari', '2026-07-02', 'Pencatatan pelanggaran siswa', 15, 'Pemanggilan siswa', 'tercatat', '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(96, 1, 96, 'Siswa 96', 96, 'TKR 2', 96, 'Membawa barang terlarang', 96, 46, 'Vicky Ramadhan', '2026-07-03', 'Pencatatan pelanggaran siswa', 20, 'Pembinaan', 'tercatat', '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(97, 1, 97, 'Siswa 97', 97, 'TKR 3', 97, 'Berbicara saat pembelajaran', 97, 47, 'Wulan Pertiwi', '2026-07-04', 'Pencatatan pelanggaran siswa', 5, 'Teguran lisan', 'tercatat', '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(98, 1, 98, 'Siswa 98', 98, 'TKR 4', 98, 'Tidak menjaga kebersihan kelas', 98, 48, 'Yusuf Maulana', '2026-07-05', 'Pencatatan pelanggaran siswa', 5, 'Pembinaan oleh wali kelas', 'tercatat', '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(99, 1, 99, 'Siswa 99', 99, 'BD', 99, 'Mengganggu kegiatan belajar', 99, 49, 'Zahra Aulia', '2026-07-06', 'Pencatatan pelanggaran siswa', 10, 'Pemanggilan siswa', 'tercatat', '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(100, 1, 100, 'Siswa 100', 100, 'TSM 1', 100, 'Tidak mengikuti pembelajaran', 100, 50, 'Andi Firmansyah', '2026-07-07', 'Pencatatan pelanggaran siswa', 10, 'Pembinaan', 'tercatat', '2026-07-07 01:00:00', '2026-07-07 01:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_siswa`
--

CREATE TABLE `t_siswa` (
  `id` int(11) NOT NULL,
  `nis` varchar(30) DEFAULT NULL,
  `nisn` varchar(20) NOT NULL,
  `nama` varchar(150) DEFAULT NULL,
  `jenis_kelamin` char(1) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` text NOT NULL,
  `status_aktif` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_siswa`
--

INSERT INTO `t_siswa` (`id`, `nis`, `nisn`, `nama`, `jenis_kelamin`, `tanggal_lahir`, `alamat`, `status_aktif`, `created_at`, `updated_at`) VALUES
(1, '124124124124124', '2523523235', 'alvin rahadian', 'L', '2009-01-02', 'Jl. Pendidikan No. 1, Tasikmalaya', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(2, '20260002', '0087654002', 'alisa ramadhani', 'P', '2010-02-04', 'Jl. Pendidikan No. 2, Tasikmalaya', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(3, '20260003', '0087654003', 'alma aura livia', 'L', '2008-03-06', 'Jl. Pendidikan No. 3, Tasikmalaya', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(4, '20260004', '0087654004', 'anis khoerunnisa', 'P', '2009-04-08', 'Jl. Pendidikan No. 4, Tasikmalaya', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(5, '20260005', '0087654005', 'azmil amira', 'L', '2010-05-10', 'Jl. Pendidikan No. 5, Tasikmalaya', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(6, '20260006', '0087654006', 'azril akbar', 'P', '2008-06-12', 'Jl. Pendidikan No. 6, Tasikmalaya', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(7, '20260007', '0087654007', 'erlangga saputra', 'L', '2009-07-14', 'Jl. Pendidikan No. 7, Tasikmalaya', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(8, '20260008', '0087654008', 'hilma himmatunnajah', 'P', '2010-08-16', 'Jl. Pendidikan No. 8, Tasikmalaya', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(9, '20260009', '0087654009', 'ilma nazya', 'L', '2008-09-18', 'Jl. Pendidikan No. 9, Tasikmalaya', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(10, '20260010', '0087654010', 'julianda dharma pangestu', 'P', '2009-10-20', 'Jl. Pendidikan No. 10, Tasikmalaya', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(11, '20260011', '0087654011', 'kayila nur fadilah', 'L', '2010-11-22', 'Jl. Pendidikan No. 11, Tasikmalaya', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(12, '20260012', '0087654012', 'moza dina nabillah', 'P', '2008-12-24', 'Jl. Pendidikan No. 12, Tasikmalaya', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(13, '20260013', '0087654013', 'muhammad alfarizi', 'L', '2009-01-26', 'Jl. Pendidikan No. 13, Tasikmalaya', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(14, '20260014', '0087654014', 'fahrin', 'P', '2010-02-01', 'Jl. Pendidikan No. 14, Tasikmalaya', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(15, '20260015', '0087654015', 'muhammad zidan', 'L', '2008-03-03', 'Jl. Pendidikan No. 15, Tasikmalaya', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(16, '20260016', '0087654016', 'muhammad zulfan', 'P', '2009-04-05', 'Jl. Pendidikan No. 16, Tasikmalaya', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(17, '20260017', '0087654017', 'raditya jeti prasetya', 'L', '2010-05-07', 'Jl. Pendidikan No. 17, Tasikmalaya', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(18, '20260018', '0087654018', 'rangga ramadiyanto nurhakim', 'P', '2008-06-09', 'Jl. Pendidikan No. 18, Tasikmalaya', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(19, '20260019', '0087654019', 'natiya nur azkiya', 'L', '2009-07-11', 'Jl. Pendidikan No. 19, Tasikmalaya', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(20, '20260020', '0087654020', 'novita puspitasari', 'P', '2010-08-13', 'Jl. Pendidikan No. 20, Tasikmalaya', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(21, '20260021', '0087654021', 'rizqi muhammad ihwani', 'L', '2008-09-15', 'Jl. Pendidikan No. 21, Tasikmalaya', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(22, '20260022', '0087654022', 'nucky andreas febrian', 'P', '2009-10-17', 'Jl. Pendidikan No. 22, Tasikmalaya', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(23, '20260023', '0087654023', 'salwa sabilatul barkah', 'L', '2010-11-19', 'Jl. Pendidikan No. 23, Tasikmalaya', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(24, '20260024', '0087654024', 'tazkia zahra', 'P', '2008-12-21', 'Jl. Pendidikan No. 24, Tasikmalaya', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(25, '20260025', '0087654025', 'Bagas Pangestu', 'L', '2009-01-23', 'Jl. Pendidikan No. 25, Tasikmalaya', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(26, '20260026', '0087654026', 'Cahya Saputra', 'P', '2010-02-25', 'Jl. Pendidikan No. 26, Tasikmalaya', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(27, '20260027', '0087654027', 'Daffa Hidayat', 'L', '2008-03-27', 'Jl. Pendidikan No. 27, Tasikmalaya', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(28, '20260028', '0087654028', 'Elsa Permatasari', 'P', '2009-04-02', 'Jl. Pendidikan No. 28, Tasikmalaya', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(29, '20260029', '0087654029', 'Farhan Ramadhan', 'L', '2010-05-04', 'Jl. Pendidikan No. 29, Tasikmalaya', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(30, '20260030', '0087654030', 'Gita Firmansyah', 'P', '2008-06-06', 'Jl. Pendidikan No. 30, Tasikmalaya', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(31, '20260031', '0087654031', 'Ahmad Fauzan', 'L', '2009-07-08', 'Jl. Pendidikan No. 31, Tasikmalaya', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(32, '20260032', '0087654032', 'Budi Maulana', 'P', '2010-08-10', 'Jl. Pendidikan No. 32, Tasikmalaya', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(33, '20260033', '0087654033', 'Citra Lestari', 'L', '2008-09-12', 'Jl. Pendidikan No. 33, Tasikmalaya', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(34, '20260034', '0087654034', 'Dimas Aditya', 'P', '2009-10-14', 'Jl. Pendidikan No. 34, Tasikmalaya', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(35, '20260035', '0087654035', 'Eka Nugraha', 'L', '2010-11-16', 'Jl. Pendidikan No. 35, Tasikmalaya', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(36, '20260036', '0087654036', 'Fajar Sari', 'P', '2008-12-18', 'Jl. Pendidikan No. 36, Tasikmalaya', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(37, '20260037', '0087654037', 'Galih Rizky', 'L', '2009-01-20', 'Jl. Pendidikan No. 37, Tasikmalaya', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(38, '20260038', '0087654038', 'Hana Permana', 'P', '2010-02-22', 'Jl. Pendidikan No. 38, Tasikmalaya', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(39, '20260039', '0087654039', 'Intan Anggraini', 'L', '2008-03-24', 'Jl. Pendidikan No. 39, Tasikmalaya', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(40, '20260040', '0087654040', 'Joko Nabila', 'P', '2009-04-26', 'Jl. Pendidikan No. 40, Tasikmalaya', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(41, '20260041', '0087654041', 'Kirana Setiawan', 'L', '2010-05-01', 'Jl. Pendidikan No. 41, Tasikmalaya', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(42, '20260042', '0087654042', 'Lukman Wijaya', 'P', '2008-06-03', 'Jl. Pendidikan No. 42, Tasikmalaya', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(43, '20260043', '0087654043', 'Maya Pratama', 'L', '2009-07-05', 'Jl. Pendidikan No. 43, Tasikmalaya', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(44, '20260044', '0087654044', 'Nadia Kurniawan', 'P', '2010-08-07', 'Jl. Pendidikan No. 44, Tasikmalaya', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(45, '20260045', '0087654045', 'Oki Pangestu', 'L', '2008-09-09', 'Jl. Pendidikan No. 45, Tasikmalaya', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(46, '20260046', '0087654046', 'Putri Saputra', 'P', '2009-10-11', 'Jl. Pendidikan No. 46, Tasikmalaya', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(47, '20260047', '0087654047', 'Raka Hidayat', 'L', '2010-11-13', 'Jl. Pendidikan No. 47, Tasikmalaya', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(48, '20260048', '0087654048', 'Salsa Permatasari', 'P', '2008-12-15', 'Jl. Pendidikan No. 48, Tasikmalaya', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(49, '20260049', '0087654049', 'Taufik Ramadhan', 'L', '2009-01-17', 'Jl. Pendidikan No. 49, Tasikmalaya', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(50, '20260050', '0087654050', 'Vina Firmansyah', 'P', '2010-02-19', 'Jl. Pendidikan No. 50, Tasikmalaya', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(51, '20260051', '0087654051', 'Wahyu Fauzan', 'L', '2008-03-21', 'Jl. Pendidikan No. 51, Tasikmalaya', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(52, '20260052', '0087654052', 'Yuni Maulana', 'P', '2009-04-23', 'Jl. Pendidikan No. 52, Tasikmalaya', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(53, '20260053', '0087654053', 'Zaki Lestari', 'L', '2010-05-25', 'Jl. Pendidikan No. 53, Tasikmalaya', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(54, '20260054', '0087654054', 'Alya Aditya', 'P', '2008-06-27', 'Jl. Pendidikan No. 54, Tasikmalaya', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(55, '20260055', '0087654055', 'Bagas Nugraha', 'L', '2009-07-02', 'Jl. Pendidikan No. 55, Tasikmalaya', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(56, '20260056', '0087654056', 'Cahya Sari', 'P', '2010-08-04', 'Jl. Pendidikan No. 56, Tasikmalaya', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(57, '20260057', '0087654057', 'Daffa Rizky', 'L', '2008-09-06', 'Jl. Pendidikan No. 57, Tasikmalaya', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(58, '20260058', '0087654058', 'Elsa Permana', 'P', '2009-10-08', 'Jl. Pendidikan No. 58, Tasikmalaya', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(59, '20260059', '0087654059', 'Farhan Anggraini', 'L', '2010-11-10', 'Jl. Pendidikan No. 59, Tasikmalaya', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(60, '20260060', '0087654060', 'Gita Nabila', 'P', '2008-12-12', 'Jl. Pendidikan No. 60, Tasikmalaya', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(61, '20260061', '0087654061', 'Ahmad Setiawan', 'L', '2009-01-14', 'Jl. Pendidikan No. 61, Tasikmalaya', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(62, '20260062', '0087654062', 'Budi Wijaya', 'P', '2010-02-16', 'Jl. Pendidikan No. 62, Tasikmalaya', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(63, '20260063', '0087654063', 'Citra Pratama', 'L', '2008-03-18', 'Jl. Pendidikan No. 63, Tasikmalaya', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(64, '20260064', '0087654064', 'Dimas Kurniawan', 'P', '2009-04-20', 'Jl. Pendidikan No. 64, Tasikmalaya', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(65, '20260065', '0087654065', 'Eka Pangestu', 'L', '2010-05-22', 'Jl. Pendidikan No. 65, Tasikmalaya', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(66, '20260066', '0087654066', 'Fajar Saputra', 'P', '2008-06-24', 'Jl. Pendidikan No. 66, Tasikmalaya', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(67, '20260067', '0087654067', 'Galih Hidayat', 'L', '2009-07-26', 'Jl. Pendidikan No. 67, Tasikmalaya', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(68, '20260068', '0087654068', 'Hana Permatasari', 'P', '2010-08-01', 'Jl. Pendidikan No. 68, Tasikmalaya', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(69, '20260069', '0087654069', 'Intan Ramadhan', 'L', '2008-09-03', 'Jl. Pendidikan No. 69, Tasikmalaya', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(70, '20260070', '0087654070', 'Joko Firmansyah', 'P', '2009-10-05', 'Jl. Pendidikan No. 70, Tasikmalaya', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(71, '20260071', '0087654071', 'Kirana Fauzan', 'L', '2010-11-07', 'Jl. Pendidikan No. 71, Tasikmalaya', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(72, '20260072', '0087654072', 'Lukman Maulana', 'P', '2008-12-09', 'Jl. Pendidikan No. 72, Tasikmalaya', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(73, '20260073', '0087654073', 'Maya Lestari', 'L', '2009-01-11', 'Jl. Pendidikan No. 73, Tasikmalaya', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(74, '20260074', '0087654074', 'Nadia Aditya', 'P', '2010-02-13', 'Jl. Pendidikan No. 74, Tasikmalaya', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(75, '20260075', '0087654075', 'Oki Nugraha', 'L', '2008-03-15', 'Jl. Pendidikan No. 75, Tasikmalaya', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(76, '20260076', '0087654076', 'Putri Sari', 'P', '2009-04-17', 'Jl. Pendidikan No. 76, Tasikmalaya', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(77, '20260077', '0087654077', 'Raka Rizky', 'L', '2010-05-19', 'Jl. Pendidikan No. 77, Tasikmalaya', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(78, '20260078', '0087654078', 'Salsa Permana', 'P', '2008-06-21', 'Jl. Pendidikan No. 78, Tasikmalaya', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(79, '20260079', '0087654079', 'Taufik Anggraini', 'L', '2009-07-23', 'Jl. Pendidikan No. 79, Tasikmalaya', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(80, '20260080', '0087654080', 'Vina Nabila', 'P', '2010-08-25', 'Jl. Pendidikan No. 80, Tasikmalaya', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(81, '20260081', '0087654081', 'Wahyu Setiawan', 'L', '2008-09-27', 'Jl. Pendidikan No. 81, Tasikmalaya', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(82, '20260082', '0087654082', 'Yuni Wijaya', 'P', '2009-10-02', 'Jl. Pendidikan No. 82, Tasikmalaya', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(83, '20260083', '0087654083', 'Zaki Pratama', 'L', '2010-11-04', 'Jl. Pendidikan No. 83, Tasikmalaya', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(84, '20260084', '0087654084', 'Alya Kurniawan', 'P', '2008-12-06', 'Jl. Pendidikan No. 84, Tasikmalaya', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(85, '20260085', '0087654085', 'Bagas Pangestu', 'L', '2009-01-08', 'Jl. Pendidikan No. 85, Tasikmalaya', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(86, '20260086', '0087654086', 'Cahya Saputra', 'P', '2010-02-10', 'Jl. Pendidikan No. 86, Tasikmalaya', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(87, '20260087', '0087654087', 'Daffa Hidayat', 'L', '2008-03-12', 'Jl. Pendidikan No. 87, Tasikmalaya', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(88, '20260088', '0087654088', 'Elsa Permatasari', 'P', '2009-04-14', 'Jl. Pendidikan No. 88, Tasikmalaya', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(89, '20260089', '0087654089', 'Farhan Ramadhan', 'L', '2010-05-16', 'Jl. Pendidikan No. 89, Tasikmalaya', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(90, '20260090', '0087654090', 'Gita Firmansyah', 'P', '2008-06-18', 'Jl. Pendidikan No. 90, Tasikmalaya', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(91, '20260091', '0087654091', 'Ahmad Fauzan', 'L', '2009-07-20', 'Jl. Pendidikan No. 91, Tasikmalaya', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(92, '20260092', '0087654092', 'Budi Maulana', 'P', '2010-08-22', 'Jl. Pendidikan No. 92, Tasikmalaya', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(93, '20260093', '0087654093', 'Citra Lestari', 'L', '2008-09-24', 'Jl. Pendidikan No. 93, Tasikmalaya', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(94, '20260094', '0087654094', 'Dimas Aditya', 'P', '2009-10-26', 'Jl. Pendidikan No. 94, Tasikmalaya', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(95, '20260095', '0087654095', 'Eka Nugraha', 'L', '2010-11-01', 'Jl. Pendidikan No. 95, Tasikmalaya', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(96, '20260096', '0087654096', 'Fajar Sari', 'P', '2008-12-03', 'Jl. Pendidikan No. 96, Tasikmalaya', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(97, '20260097', '0087654097', 'Galih Rizky', 'L', '2009-01-05', 'Jl. Pendidikan No. 97, Tasikmalaya', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(98, '20260098', '0087654098', 'Hana Permana', 'P', '2010-02-07', 'Jl. Pendidikan No. 98, Tasikmalaya', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(99, '20260099', '0087654099', 'Intan Anggraini', 'L', '2008-03-09', 'Jl. Pendidikan No. 99, Tasikmalaya', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(100, '20260100', '0087654100', 'Joko Nabila', 'P', '2009-04-11', 'Jl. Pendidikan No. 100, Tasikmalaya', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(101, NULL, '', 'Alvin Rahadian', '', '2008-08-03', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(102, NULL, '', 'Alisa Ramadhani', '', '2008-09-28', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(103, NULL, '', 'Alma Aura Livia', '', '2008-08-26', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(104, NULL, '', 'Anis Khoerunnisa N.R', '', '2008-09-25', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(105, NULL, '', 'Azmil Amira', '', '2009-10-30', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(106, NULL, '', 'Azril Akbar', '', '2008-08-21', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(107, NULL, '', 'Erlangga Saputra', '', '2008-06-06', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(108, NULL, '', 'Hilma Himmatunnajah', '', '2009-03-25', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(109, NULL, '', 'ilma nazya', '', '2009-02-16', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(110, NULL, '', 'Julianda Dharma Pangestu', '', '2008-07-02', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(111, NULL, '', 'Kayila Nur Fadilah', '', '2009-07-15', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(112, NULL, '', 'Moza Dina Nabillah', '', '2008-11-21', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(113, NULL, '', 'Muhammad Al Farizi', '', '2008-11-13', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(114, NULL, '', 'fahrin', '', '2008-12-20', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(115, NULL, '', 'Muhammad Zidan', '', '2006-03-30', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(116, NULL, '', 'muhammad zulfan', '', '2009-01-27', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(117, NULL, '', 'Raditya Jeti Prasetya', '', '2009-09-01', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(118, NULL, '', 'Rangga Ramadiyanto Nurhakim', '', '2008-05-21', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(119, NULL, '', 'Natiya nur Azkiya', '', '2008-12-26', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(120, NULL, '', 'Novita Puspitasari', '', '2008-11-02', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(121, NULL, '', 'Risqi Muhamad Ihwani', '', '2009-07-22', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(122, NULL, '', 'Nucky Andreas febrian', '', '2008-02-16', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(123, NULL, '', 'Salwa Sabilatul Barkah', '', '2008-09-24', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11'),
(124, NULL, '', 'Tazkia Zahra', '', '2009-01-09', '', 0, '2026-11-10 08:38:11', '2026-11-10 08:38:11');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_tahun_ajaran`
--

CREATE TABLE `t_tahun_ajaran` (
  `id` int(11) NOT NULL,
  `nama` varchar(20) DEFAULT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date NOT NULL,
  `status_aktif` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_tahun_ajaran`
--

INSERT INTO `t_tahun_ajaran` (`id`, `nama`, `tanggal_mulai`, `tanggal_selesai`, `status_aktif`, `created_at`, `updated_at`) VALUES
(1, '2020/2021', '2020-08-10', '2021-06-30', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(3, '2020/2021', '2020-07-01', '2021-06-30', 0, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(4, '2020/2021', '2020-07-01', '2021-06-30', 0, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(5, '2021/2022', '2021-07-01', '2022-06-30', 0, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(6, '2021/2022', '2021-07-01', '2022-06-30', 0, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(7, '2021/2022', '2021-07-01', '2022-06-30', 0, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(8, '2021/2022', '2021-07-01', '2022-06-30', 0, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(9, '2022/2023', '2022-07-01', '2023-06-30', 0, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(10, '2022/2023', '2022-07-01', '2023-06-30', 0, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(11, '2022/2023', '2022-07-01', '2023-06-30', 0, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(12, '2022/2023', '2022-07-01', '2023-06-30', 0, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(13, '2023/2024', '2023-07-01', '2024-06-30', 0, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(14, '2023/2024', '2023-07-01', '2024-06-30', 0, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(15, '2023/2024', '2023-07-01', '2024-06-30', 0, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(16, '2023/2024', '2023-07-01', '2024-06-30', 0, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(17, '2024/2025', '2024-07-01', '2025-06-30', 0, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(18, '2024/2025', '2024-07-01', '2025-06-30', 0, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(19, '2024/2025', '2024-07-01', '2025-06-30', 0, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(20, '2024/2025', '2024-07-01', '2025-06-30', 0, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(21, '2025/2026', '2025-07-01', '2026-06-30', 0, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(22, '2025/2026', '2025-07-01', '2026-06-30', 0, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(23, '2025/2026', '2025-07-01', '2026-06-30', 0, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(24, '2025/2026', '2025-07-01', '2026-06-30', 0, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(25, '2026/2027', '2026-07-01', '2027-06-30', 0, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(26, '2026/2027', '2026-07-01', '2027-06-30', 0, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(27, '2026/2027', '2026-07-01', '2027-06-30', 0, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(28, '2026/2027', '2026-07-01', '2027-06-30', 0, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(29, '2027/2028', '2027-07-01', '2028-06-30', 0, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(30, '2027/2028', '2027-07-01', '2028-06-30', 0, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(31, '2027/2028', '2027-07-01', '2028-06-30', 0, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(32, '2027/2028', '2027-07-01', '2028-06-30', 0, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(33, '2028/2029', '2028-07-01', '2029-06-30', 0, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(34, '2028/2029', '2028-07-01', '2029-06-30', 0, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(35, '2028/2029', '2028-07-01', '2029-06-30', 0, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(36, '2028/2029', '2028-07-01', '2029-06-30', 0, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(37, '2029/2030', '2029-07-01', '2030-06-30', 0, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(38, '2029/2030', '2029-07-01', '2030-06-30', 0, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(39, '2029/2030', '2029-07-01', '2030-06-30', 0, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(40, '2029/2030', '2029-07-01', '2030-06-30', 0, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(41, '2030/2031', '2030-07-01', '2031-06-30', 0, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(42, '2030/2031', '2030-07-01', '2031-06-30', 0, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(43, '2030/2031', '2030-07-01', '2031-06-30', 0, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(44, '2030/2031', '2030-07-01', '2031-06-30', 0, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(45, '2031/2032', '2031-07-01', '2032-06-30', 0, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(46, '2031/2032', '2031-07-01', '2032-06-30', 0, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(47, '2031/2032', '2031-07-01', '2032-06-30', 0, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(48, '2031/2032', '2031-07-01', '2032-06-30', 0, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(49, '2032/2033', '2032-07-01', '2033-06-30', 0, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(50, '2032/2033', '2032-07-01', '2033-06-30', 0, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(51, '2032/2033', '2032-07-01', '2033-06-30', 0, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(52, '2032/2033', '2032-07-01', '2033-06-30', 0, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(53, '2033/2034', '2033-07-01', '2034-06-30', 0, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(54, '2033/2034', '2033-07-01', '2034-06-30', 0, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(55, '2033/2034', '2033-07-01', '2034-06-30', 0, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(56, '2033/2034', '2033-07-01', '2034-06-30', 0, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(57, '2034/2035', '2034-07-01', '2035-06-30', 0, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(58, '2034/2035', '2034-07-01', '2035-06-30', 0, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(59, '2034/2035', '2034-07-01', '2035-06-30', 0, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(60, '2034/2035', '2034-07-01', '2035-06-30', 0, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(61, '2035/2036', '2035-07-01', '2036-06-30', 0, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(62, '2035/2036', '2035-07-01', '2036-06-30', 0, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(63, '2035/2036', '2035-07-01', '2036-06-30', 0, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(64, '2035/2036', '2035-07-01', '2036-06-30', 0, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(65, '2036/2037', '2036-07-01', '2037-06-30', 0, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(66, '2036/2037', '2036-07-01', '2037-06-30', 0, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(67, '2036/2037', '2036-07-01', '2037-06-30', 0, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(68, '2036/2037', '2036-07-01', '2037-06-30', 0, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(69, '2037/2038', '2037-07-01', '2038-06-30', 0, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(70, '2037/2038', '2037-07-01', '2038-06-30', 0, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(71, '2037/2038', '2037-07-01', '2038-06-30', 0, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(72, '2037/2038', '2037-07-01', '2038-06-30', 0, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(73, '2038/2039', '2038-07-01', '2039-06-30', 0, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(74, '2038/2039', '2038-07-01', '2039-06-30', 0, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(75, '2038/2039', '2038-07-01', '2039-06-30', 0, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(76, '2038/2039', '2038-07-01', '2039-06-30', 0, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(77, '2039/2040', '2039-07-01', '2040-06-30', 0, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(78, '2039/2040', '2039-07-01', '2040-06-30', 0, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(79, '2039/2040', '2039-07-01', '2040-06-30', 0, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(80, '2039/2040', '2039-07-01', '2040-06-30', 0, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(81, '2040/2041', '2040-07-01', '2041-06-30', 0, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(82, '2040/2041', '2040-07-01', '2041-06-30', 0, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(83, '2040/2041', '2040-07-01', '2041-06-30', 0, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(84, '2040/2041', '2040-07-01', '2041-06-30', 0, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(85, '2041/2042', '2041-07-01', '2042-06-30', 0, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(86, '2041/2042', '2041-07-01', '2042-06-30', 0, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(87, '2041/2042', '2041-07-01', '2042-06-30', 0, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(88, '2041/2042', '2041-07-01', '2042-06-30', 0, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(89, '2042/2043', '2042-07-01', '2043-06-30', 0, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(90, '2042/2043', '2042-07-01', '2043-06-30', 0, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(91, '2042/2043', '2042-07-01', '2043-06-30', 0, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(92, '2042/2043', '2042-07-01', '2043-06-30', 0, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(93, '2043/2044', '2043-07-01', '2044-06-30', 0, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(94, '2043/2044', '2043-07-01', '2044-06-30', 0, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(95, '2043/2044', '2043-07-01', '2044-06-30', 0, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(96, '2043/2044', '2043-07-01', '2044-06-30', 0, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(97, '2044/2045', '2044-07-01', '2045-06-30', 0, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(98, '2044/2045', '2044-07-01', '2045-06-30', 0, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(99, '2044/2045', '2044-07-01', '2045-06-30', 0, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(100, '2044/2045', '2044-07-01', '2045-06-30', 0, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(101, '2025/2026', '0000-00-00', '0000-00-00', 0, '2026-10-21 06:19:27', '2026-10-21 06:19:27'),
(102, '2025/2026', '2022-02-22', '2022-02-23', 0, '2026-10-21 06:25:45', '2026-10-21 06:25:45'),
(103, '2025/2026', '2023-02-23', '2023-02-24', 0, '2026-10-21 06:30:22', '2026-10-21 06:30:22'),
(104, '2025/2026', '0000-00-00', '0000-00-00', 0, '2026-11-09 00:52:21', '2026-11-09 00:52:21');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_users`
--

CREATE TABLE `t_users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `email_verified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `password` varchar(255) DEFAULT NULL,
  `remember_token` varchar(100) NOT NULL,
  `role` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_users`
--

INSERT INTO `t_users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `role`, `created_at`, `updated_at`) VALUES
(1, 'Ahmad Ramadhan', 'admin@gmail.com', '2026-07-01 01:00:00', 'admin123', '', 'admin', '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(2, 'Budi Permana', 'admin@gmail.com', '2026-07-01 01:00:00', 'admin123', '', 'admin', '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(3, 'Citra Hidayat', 'admin@gmail.com', '2026-07-01 01:00:00', 'admin123', '', 'admin', '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(4, 'Dimas Sari', 'admin@gmail.com', '2026-07-01 01:00:00', 'admin123', '', 'admin', '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(5, 'Eka Pangestu', 'admin@gmail.com', '2026-07-01 01:00:00', 'admin123', '', 'admin', '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(6, 'Fajar Aditya', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(7, 'Galih Pratama', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(8, 'Hana Maulana', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(9, 'Intan Setiawan', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(10, 'Joko Firmansyah', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(11, 'Kirana Anggraini', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(12, 'Lukman Permatasari', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(13, 'Maya Rizky', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(14, 'Nadia Saputra', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(15, 'Oki Nugraha', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(16, 'Putri Kurniawan', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(17, 'Raka Lestari', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(18, 'Salsa Wijaya', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(19, 'Taufik Fauzan', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(20, 'Vina Nabila', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(21, 'Wahyu Ramadhan', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(22, 'Yuni Permana', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(23, 'Zaki Hidayat', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(24, 'Alya Sari', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(25, 'Bagas Pangestu', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(26, 'Cahya Aditya', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(27, 'Daffa Pratama', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(28, 'Elsa Maulana', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(29, 'Farhan Setiawan', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(30, 'Gita Firmansyah', 'guru@gmail.com', '2026-07-01 01:00:00', 'guru123', '', 'guru', '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(31, 'Ahmad Anggraini', 'user031@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(32, 'Budi Permatasari', 'user032@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(33, 'Citra Rizky', 'user033@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(34, 'Dimas Saputra', 'user034@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(35, 'Eka Nugraha', 'user035@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(36, 'Fajar Kurniawan', 'user036@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(37, 'Galih Lestari', 'user037@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(38, 'Hana Wijaya', 'user038@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(39, 'Intan Fauzan', 'user039@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(40, 'Joko Nabila', 'user040@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(41, 'Kirana Ramadhan', 'user041@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(42, 'Lukman Permana', 'user042@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(43, 'Maya Hidayat', 'user043@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(44, 'Nadia Sari', 'user044@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(45, 'Oki Pangestu', 'user045@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(46, 'Putri Aditya', 'user046@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(47, 'Raka Pratama', 'user047@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(48, 'Salsa Maulana', 'user048@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(49, 'Taufik Setiawan', 'user049@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(50, 'Vina Firmansyah', 'user050@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(51, 'Wahyu Anggraini', 'user051@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(52, 'Yuni Permatasari', 'user052@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(53, 'Zaki Rizky', 'user053@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(54, 'Alya Saputra', 'user054@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(55, 'Bagas Nugraha', 'user055@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(56, 'Cahya Kurniawan', 'user056@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(57, 'Daffa Lestari', 'user057@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(58, 'Elsa Wijaya', 'user058@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(59, 'Farhan Fauzan', 'user059@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(60, 'Gita Nabila', 'user060@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(61, 'Ahmad Ramadhan', 'user061@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(62, 'Budi Permana', 'user062@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(63, 'Citra Hidayat', 'user063@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(64, 'Dimas Sari', 'user064@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(65, 'Eka Pangestu', 'user065@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(66, 'Fajar Aditya', 'user066@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(67, 'Galih Pratama', 'user067@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(68, 'Hana Maulana', 'user068@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(69, 'Intan Setiawan', 'user069@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(70, 'Joko Firmansyah', 'user070@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(71, 'Kirana Anggraini', 'user071@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(72, 'Lukman Permatasari', 'user072@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(73, 'Maya Rizky', 'user073@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(74, 'Nadia Saputra', 'user074@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(75, 'Oki Nugraha', 'user075@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(76, 'Putri Kurniawan', 'user076@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(77, 'Raka Lestari', 'user077@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(78, 'Salsa Wijaya', 'user078@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(79, 'Taufik Fauzan', 'user079@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(80, 'Vina Nabila', 'user080@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(81, 'Wahyu Ramadhan', 'user081@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(82, 'Yuni Permana', 'user082@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(83, 'Zaki Hidayat', 'user083@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(84, 'Alya Sari', 'user084@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(85, 'Bagas Pangestu', 'user085@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(86, 'Cahya Aditya', 'user086@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(87, 'Daffa Pratama', 'user087@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(88, 'Elsa Maulana', 'user088@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(89, 'Farhan Setiawan', 'user089@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(90, 'Gita Firmansyah', 'user090@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(91, 'Ahmad Anggraini', 'user091@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(92, 'Budi Permatasari', 'user092@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(93, 'Citra Rizky', 'user093@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(94, 'Dimas Saputra', 'user094@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(95, 'Eka Nugraha', 'user095@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(96, 'Fajar Kurniawan', 'user096@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(97, 'Galih Lestari', 'user097@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(98, 'Hana Wijaya', 'user098@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(99, 'Intan Fauzan', 'user099@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(100, 'Joko Nabila', 'user100@sekolah.test', '2026-07-01 01:00:00', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCk0s3ZQmQxK9v7l3M6', '', 'petugas', '2026-07-07 01:00:00', '2026-07-07 01:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_wali_kelas`
--

CREATE TABLE `t_wali_kelas` (
  `id` int(11) NOT NULL,
  `tahun_ajaran_id` int(11) DEFAULT NULL,
  `kelas_id` int(11) DEFAULT NULL,
  `guru_id` int(11) DEFAULT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date NOT NULL,
  `status_aktif` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_wali_kelas`
--

INSERT INTO `t_wali_kelas` (`id`, `tahun_ajaran_id`, `kelas_id`, `guru_id`, `tanggal_mulai`, `tanggal_selesai`, `status_aktif`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, '2026-07-01', '0000-00-00', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(2, 1, 2, 2, '2026-07-01', '0000-00-00', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(3, 1, 3, 3, '2026-07-01', '0000-00-00', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(4, 1, 4, 4, '2026-07-01', '0000-00-00', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(5, 1, 5, 5, '2026-07-01', '0000-00-00', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(6, 1, 6, 6, '2026-07-01', '0000-00-00', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(7, 1, 7, 7, '2026-07-01', '0000-00-00', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(8, 1, 8, 8, '2026-07-01', '0000-00-00', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(9, 1, 9, 9, '2026-07-01', '0000-00-00', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(10, 1, 10, 10, '2026-07-01', '0000-00-00', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(11, 1, 11, 11, '2026-07-01', '0000-00-00', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(12, 1, 12, 12, '2026-07-01', '0000-00-00', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(13, 1, 13, 13, '2026-07-01', '0000-00-00', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(14, 1, 14, 14, '2026-07-01', '0000-00-00', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(15, 1, 15, 15, '2026-07-01', '0000-00-00', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(16, 1, 16, 16, '2026-07-01', '0000-00-00', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(17, 1, 17, 17, '2026-07-01', '0000-00-00', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(18, 1, 18, 18, '2026-07-01', '0000-00-00', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(19, 1, 19, 19, '2026-07-01', '0000-00-00', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(20, 1, 20, 20, '2026-07-01', '0000-00-00', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(21, 1, 21, 21, '2026-07-01', '0000-00-00', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(22, 1, 22, 22, '2026-07-01', '0000-00-00', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(23, 1, 23, 23, '2026-07-01', '0000-00-00', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(24, 1, 24, 24, '2026-07-01', '0000-00-00', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(25, 1, 25, 25, '2026-07-01', '0000-00-00', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(26, 1, 26, 26, '2026-07-01', '0000-00-00', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(27, 1, 27, 27, '2026-07-01', '0000-00-00', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(28, 1, 28, 28, '2026-07-01', '0000-00-00', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(29, 1, 29, 29, '2026-07-01', '0000-00-00', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(30, 1, 30, 30, '2026-07-01', '0000-00-00', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(31, 1, 31, 31, '2026-07-01', '0000-00-00', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(32, 1, 32, 32, '2026-07-01', '0000-00-00', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(33, 1, 33, 33, '2026-07-01', '0000-00-00', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(34, 1, 34, 34, '2026-07-01', '0000-00-00', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(35, 1, 35, 35, '2026-07-01', '0000-00-00', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(36, 1, 36, 36, '2026-07-01', '0000-00-00', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(37, 1, 37, 37, '2026-07-01', '0000-00-00', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(38, 1, 38, 38, '2026-07-01', '0000-00-00', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(39, 1, 39, 39, '2026-07-01', '0000-00-00', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(40, 1, 40, 40, '2026-07-01', '0000-00-00', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(41, 1, 41, 41, '2026-07-01', '0000-00-00', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(42, 1, 42, 42, '2026-07-01', '0000-00-00', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(43, 1, 43, 43, '2026-07-01', '0000-00-00', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(44, 1, 44, 44, '2026-07-01', '0000-00-00', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(45, 1, 45, 45, '2026-07-01', '0000-00-00', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(46, 1, 46, 46, '2026-07-01', '0000-00-00', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(47, 1, 47, 47, '2026-07-01', '0000-00-00', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(48, 1, 48, 48, '2026-07-01', '0000-00-00', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(49, 1, 49, 49, '2026-07-01', '0000-00-00', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(50, 1, 50, 50, '2026-07-01', '0000-00-00', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(51, 1, 51, 1, '2026-07-01', '0000-00-00', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(52, 1, 52, 2, '2026-07-01', '0000-00-00', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(53, 1, 53, 3, '2026-07-01', '0000-00-00', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(54, 1, 54, 4, '2026-07-01', '0000-00-00', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(55, 1, 55, 5, '2026-07-01', '0000-00-00', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(56, 1, 56, 6, '2026-07-01', '0000-00-00', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(57, 1, 57, 7, '2026-07-01', '0000-00-00', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(58, 1, 58, 8, '2026-07-01', '0000-00-00', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(59, 1, 59, 9, '2026-07-01', '0000-00-00', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(60, 1, 60, 10, '2026-07-01', '0000-00-00', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(61, 1, 61, 11, '2026-07-01', '0000-00-00', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(62, 1, 62, 12, '2026-07-01', '0000-00-00', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(63, 1, 63, 13, '2026-07-01', '0000-00-00', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(64, 1, 64, 14, '2026-07-01', '0000-00-00', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(65, 1, 65, 15, '2026-07-01', '0000-00-00', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(66, 1, 66, 16, '2026-07-01', '0000-00-00', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(67, 1, 67, 17, '2026-07-01', '0000-00-00', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(68, 1, 68, 18, '2026-07-01', '0000-00-00', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(69, 1, 69, 19, '2026-07-01', '0000-00-00', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00'),
(70, 1, 70, 20, '2026-07-01', '0000-00-00', 1, '2026-07-08 01:00:00', '2026-07-08 01:00:00'),
(71, 1, 71, 21, '2026-07-01', '0000-00-00', 1, '2026-07-09 01:00:00', '2026-07-09 01:00:00'),
(72, 1, 72, 22, '2026-07-01', '0000-00-00', 1, '2026-07-10 01:00:00', '2026-07-10 01:00:00'),
(73, 1, 73, 23, '2026-07-01', '0000-00-00', 1, '2026-07-11 01:00:00', '2026-07-11 01:00:00'),
(74, 1, 74, 24, '2026-07-01', '0000-00-00', 1, '2026-07-12 01:00:00', '2026-07-12 01:00:00'),
(75, 1, 75, 25, '2026-07-01', '0000-00-00', 1, '2026-07-13 01:00:00', '2026-07-13 01:00:00'),
(76, 1, 76, 26, '2026-07-01', '0000-00-00', 1, '2026-07-14 01:00:00', '2026-07-14 01:00:00'),
(77, 1, 77, 27, '2026-07-01', '0000-00-00', 1, '2026-07-15 01:00:00', '2026-07-15 01:00:00'),
(78, 1, 78, 28, '2026-07-01', '0000-00-00', 1, '2026-07-16 01:00:00', '2026-07-16 01:00:00'),
(79, 1, 79, 29, '2026-07-01', '0000-00-00', 1, '2026-07-17 01:00:00', '2026-07-17 01:00:00'),
(80, 1, 80, 30, '2026-07-01', '0000-00-00', 1, '2026-07-18 01:00:00', '2026-07-18 01:00:00'),
(81, 1, 81, 31, '2026-07-01', '0000-00-00', 1, '2026-07-19 01:00:00', '2026-07-19 01:00:00'),
(82, 1, 82, 32, '2026-07-01', '0000-00-00', 1, '2026-07-20 01:00:00', '2026-07-20 01:00:00'),
(83, 1, 83, 33, '2026-07-01', '0000-00-00', 1, '2026-07-21 01:00:00', '2026-07-21 01:00:00'),
(84, 1, 84, 34, '2026-07-01', '0000-00-00', 1, '2026-07-22 01:00:00', '2026-07-22 01:00:00'),
(85, 1, 85, 35, '2026-07-01', '0000-00-00', 1, '2026-07-23 01:00:00', '2026-07-23 01:00:00'),
(86, 1, 86, 36, '2026-07-01', '0000-00-00', 1, '2026-07-24 01:00:00', '2026-07-24 01:00:00'),
(87, 1, 87, 37, '2026-07-01', '0000-00-00', 1, '2026-07-25 01:00:00', '2026-07-25 01:00:00'),
(88, 1, 88, 38, '2026-07-01', '0000-00-00', 1, '2026-07-26 01:00:00', '2026-07-26 01:00:00'),
(89, 1, 89, 39, '2026-07-01', '0000-00-00', 1, '2026-07-27 01:00:00', '2026-07-27 01:00:00'),
(90, 1, 90, 40, '2026-07-01', '0000-00-00', 1, '2026-07-28 01:00:00', '2026-07-28 01:00:00'),
(91, 1, 91, 41, '2026-07-01', '0000-00-00', 1, '2026-07-29 01:00:00', '2026-07-29 01:00:00'),
(92, 1, 92, 42, '2026-07-01', '0000-00-00', 1, '2026-07-30 01:00:00', '2026-07-30 01:00:00'),
(93, 1, 93, 43, '2026-07-01', '0000-00-00', 1, '2026-07-31 01:00:00', '2026-07-31 01:00:00'),
(94, 1, 94, 44, '2026-07-01', '0000-00-00', 1, '2026-07-01 01:00:00', '2026-07-01 01:00:00'),
(95, 1, 95, 45, '2026-07-01', '0000-00-00', 1, '2026-07-02 01:00:00', '2026-07-02 01:00:00'),
(96, 1, 96, 46, '2026-07-01', '0000-00-00', 1, '2026-07-03 01:00:00', '2026-07-03 01:00:00'),
(97, 1, 97, 47, '2026-07-01', '0000-00-00', 1, '2026-07-04 01:00:00', '2026-07-04 01:00:00'),
(98, 1, 98, 48, '2026-07-01', '0000-00-00', 1, '2026-07-05 01:00:00', '2026-07-05 01:00:00'),
(99, 1, 99, 49, '2026-07-01', '0000-00-00', 1, '2026-07-06 01:00:00', '2026-07-06 01:00:00'),
(100, 1, 100, 50, '2026-07-01', '0000-00-00', 1, '2026-07-07 01:00:00', '2026-07-07 01:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_user` varchar(100) NOT NULL,
  `role` enum('Admin','Karyawan/Kasir','Pemilik') NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id_user`, `username`, `password`, `nama_user`, `role`, `created_at`) VALUES
(1, 'admin', '$2y$12$lH1QHl2qI/tAeuD9yeUd7OhfNhhCvZkockDNpvMqkVQdbZrwnK/aq', 'Administrator', 'Admin', '2026-09-18 10:08:18'),
(2, 'kasir', '$2y$12$3/Z45ovSx.bfrA/dyTfhZOx4NIoxGO410JyqbgtbidVUOSnWA1gve', 'Karyawan Kasir', 'Karyawan/Kasir', '2026-09-18 10:08:18'),
(3, 'pemilik', '$2y$12$VKHQGcnzTa/SOXPNNJR2KO5rSXS04GKZcgF52a1zOMAFGXC0JU3Qu', 'Pemilik Usaha', 'Pemilik', '2026-09-18 10:08:18');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `fk_detail_transaksi` (`id_transaksi`),
  ADD KEY `fk_detail_produk` (`id_produk`);

--
-- Indeks untuk tabel `kategori_pelanggaran`
--
ALTER TABLE `kategori_pelanggaran`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`),
  ADD UNIQUE KEY `kode_produk` (`kode_produk`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `fk_transaksi_user` (`id_user`),
  ADD KEY `fk_transaksi_pelanggan` (`id_pelanggan`);

--
-- Indeks untuk tabel `t_guru`
--
ALTER TABLE `t_guru`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `t_kategori_pelanggaran`
--
ALTER TABLE `t_kategori_pelanggaran`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `t_kelas`
--
ALTER TABLE `t_kelas`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `t_kelas_siswa`
--
ALTER TABLE `t_kelas_siswa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `siswa_id` (`siswa_id`),
  ADD KEY `tahun_ajaran_id` (`tahun_ajaran_id`),
  ADD KEY `kelas_id` (`kelas_id`);

--
-- Indeks untuk tabel `t_pelanggaran`
--
ALTER TABLE `t_pelanggaran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pelanggaran_kategori_id` (`pelanggaran_kategori_id`);

--
-- Indeks untuk tabel `t_pelanggaran_kategori`
--
ALTER TABLE `t_pelanggaran_kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `t_pelanggaran_siswa`
--
ALTER TABLE `t_pelanggaran_siswa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tahun_ajaran_id` (`tahun_ajaran_id`),
  ADD KEY `siswa_id` (`siswa_id`),
  ADD KEY `kelas_id` (`kelas_id`),
  ADD KEY `pelanggaran_id` (`pelanggaran_id`),
  ADD KEY `pelanggaran_kategori_id` (`pelanggaran_kategori_id`),
  ADD KEY `guru_id` (`guru_id`);

--
-- Indeks untuk tabel `t_siswa`
--
ALTER TABLE `t_siswa`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `t_tahun_ajaran`
--
ALTER TABLE `t_tahun_ajaran`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `t_users`
--
ALTER TABLE `t_users`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `t_wali_kelas`
--
ALTER TABLE `t_wali_kelas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tahun_ajaran_id` (`tahun_ajaran_id`),
  ADD KEY `kelas_id` (`kelas_id`),
  ADD KEY `guru_id` (`guru_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `kategori_pelanggaran`
--
ALTER TABLE `kategori_pelanggaran`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `t_guru`
--
ALTER TABLE `t_guru`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT untuk tabel `t_kategori_pelanggaran`
--
ALTER TABLE `t_kategori_pelanggaran`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT untuk tabel `t_kelas`
--
ALTER TABLE `t_kelas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT untuk tabel `t_kelas_siswa`
--
ALTER TABLE `t_kelas_siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT untuk tabel `t_pelanggaran`
--
ALTER TABLE `t_pelanggaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT untuk tabel `t_pelanggaran_kategori`
--
ALTER TABLE `t_pelanggaran_kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT untuk tabel `t_pelanggaran_siswa`
--
ALTER TABLE `t_pelanggaran_siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT untuk tabel `t_siswa`
--
ALTER TABLE `t_siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT untuk tabel `t_tahun_ajaran`
--
ALTER TABLE `t_tahun_ajaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT untuk tabel `t_users`
--
ALTER TABLE `t_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT untuk tabel `t_wali_kelas`
--
ALTER TABLE `t_wali_kelas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD CONSTRAINT `fk_detail_produk` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id_produk`),
  ADD CONSTRAINT `fk_detail_transaksi` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksi` (`id_transaksi`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `fk_transaksi_pelanggan` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`),
  ADD CONSTRAINT `fk_transaksi_user` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`);

--
-- Ketidakleluasaan untuk tabel `t_guru`
--
ALTER TABLE `t_guru`
  ADD CONSTRAINT `t_guru_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `t_users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `t_kelas_siswa`
--
ALTER TABLE `t_kelas_siswa`
  ADD CONSTRAINT `t_kelas_siswa_ibfk_1` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `t_tahun_ajaran` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `t_kelas_siswa_ibfk_2` FOREIGN KEY (`kelas_id`) REFERENCES `t_kelas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `t_kelas_siswa_ibfk_3` FOREIGN KEY (`siswa_id`) REFERENCES `t_siswa` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `t_pelanggaran`
--
ALTER TABLE `t_pelanggaran`
  ADD CONSTRAINT `t_pelanggaran_ibfk_1` FOREIGN KEY (`pelanggaran_kategori_id`) REFERENCES `t_pelanggaran_kategori` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `t_pelanggaran_siswa`
--
ALTER TABLE `t_pelanggaran_siswa`
  ADD CONSTRAINT `t_pelanggaran_siswa_ibfk_1` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `t_tahun_ajaran` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `t_pelanggaran_siswa_ibfk_2` FOREIGN KEY (`guru_id`) REFERENCES `t_guru` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `t_pelanggaran_siswa_ibfk_3` FOREIGN KEY (`kelas_id`) REFERENCES `t_kelas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `t_pelanggaran_siswa_ibfk_4` FOREIGN KEY (`pelanggaran_kategori_id`) REFERENCES `t_pelanggaran_kategori` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `t_pelanggaran_siswa_ibfk_5` FOREIGN KEY (`pelanggaran_id`) REFERENCES `t_pelanggaran` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `t_pelanggaran_siswa_ibfk_6` FOREIGN KEY (`siswa_id`) REFERENCES `t_siswa` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `t_wali_kelas`
--
ALTER TABLE `t_wali_kelas`
  ADD CONSTRAINT `t_wali_kelas_ibfk_1` FOREIGN KEY (`guru_id`) REFERENCES `t_guru` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `t_wali_kelas_ibfk_2` FOREIGN KEY (`kelas_id`) REFERENCES `t_kelas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `t_wali_kelas_ibfk_3` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `t_tahun_ajaran` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
